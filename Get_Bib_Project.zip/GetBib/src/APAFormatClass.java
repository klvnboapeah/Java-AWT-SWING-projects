/***************************************
 * Advanced Programming semester long project
 * Fall 2013.
 ***************************************/

/**
 *
 * @author Kelvin B
 */
public class APAFormatClass { //No static class
        /// <summary>
        /// this method create the APA format for the book
        /// </summary>
        /// <param name="src">the book source</param>
        /// <returns>the formatted APA format</returns>
        public static String createAPAFormat(GetBibSources src){
            String s = "";
            s = src.Authors() + ". (" + src.Date() + "). " + src.returnSourceTitle() + ". " + src.returnPlaceOfPub() + ": " + src.returnPublisher(); 
            return s;
        }
    
}
