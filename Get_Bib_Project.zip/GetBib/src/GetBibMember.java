/***************************************
 * Advanced Programming semester long project
 * Fall 2013.
 ***************************************/
import java.util.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
 import java.awt.event.ActionListener;

/**
 *
 * @author Kelvin B
 */
public class GetBibMember {
        //Fields
        private String username;
        private String password;
        private String email;
        private String question;
        private String answer;
        private String date;

       /// <summary>
        /// No-argument constructor
       /// </summary>
        public GetBibMember() //No-argument constructor
        {
            this.username = username;
            this.password = password;
            this.email = email;
            this.question = question;
            this.answer = answer;
            this.date = date;
        }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="username">username</param>
        /// <param name="password">password</param>
        /// <param name="email">email address</param>
        /// <param name="question">security question</param>
        /// <param name="answer">answer</param>
        /// <param name="date">date the account was created</param>
        public GetBibMember(String username, String password, String email, String question, String answer, String date){ //A custom constructor
            this.username = username;
            this.password = password;
            this.email = email;
            this.question = question;
            this.answer = answer;
            this.date = date;
        }
        
        /// <summary>
        /// Return the username of the account
        /// </summary>
        /// <returns>the username</returns>
        public String returnUsername(){
            return username;
        }

        /// <summary>
        /// set the usename of the account
        /// </summary>
        /// <param name="str">the new user name</param>
        public void setUsername(String str){
            username = str;
        }


        /// <summary>
        /// returns the account's password
        /// </summary>
        /// <returns>the password</returns>
        public String returnPassword(){
            return password;
            }

        /// <summary>
        /// sets the account's password
        /// </summary>
        /// <param name="str">the passwords</param>
        public void setPassword(String str){
            password = str;
            }
        

        /// <summary>
        /// returns the email linked to the account
        /// </summary>
        /// <returns>the email address</returns>
        public String returnEmail(){
            return email;
        }
        
        /// <summary>
        /// sets the email address linked to the account
        /// </summary>
        /// <param name="str">the email address</param>
        public void setEmail(String str){
            email = str;
        }
        

        /// <summary>
        /// return the security question of the account
        /// </summary>
        /// <returns>the security question</returns>
        public String returnQuestion(){
            return question;
        }

        /// <summary>
        /// sets the security question of the account
        /// </summary>
        /// <param name="str">the security question</param>
        public void setQuestion(String str){
                question = str;
            }
        

        /// <summary>
        /// returns the security question's answer
        /// </summary>
        /// <returns>the answer</returns>
        public String returnAnswer(){
            return answer;
            }

        /// <summary>
        /// set the answer to the security question of the account
        /// </summary>
        /// <param name="str">the answer</param>
        public void setAnswer(String str){
                answer = str;
        }
       
 /// <summary>
 /// returns the date or time the user account was created
 /// </summary>
 /// <returns>the date or time</returns>
        public String returnDate(){
            return date;
        }

        /// <summary>
        /// sets the date or time the user account was created
        /// </summary>
        /// <param name="str">the date or time</param>
        public void setDate(String str){
            date = str;
            }
    
}
