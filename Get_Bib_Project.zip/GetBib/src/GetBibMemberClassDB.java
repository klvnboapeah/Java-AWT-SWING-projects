/***************************************
 * Advanced Programming semester long project
 * Fall 2013.
 ***************************************/
import java.util.*;
import javax.swing.*;
import java.io.*;
import java.sql.*;
import net.proteanit.sql.*;

/**
 *
 * @author Kelvin B
 */
public class GetBibMemberClassDB {
    //Member variables
    static ResultSet res = null;
    static PreparedStatement pst = null;
    

    //Establishes the actual connection to the Bibliography database 
    private static Connection connectionDB(){
        
        try{
            Class.forName("org.sqlite.JDBC");
            Connection sqlite_conn1 = DriverManager.getConnection("jdbc:sqlite:GetBibliography.db"); //Note this
         //   JOptionPane.showMessageDialog(null, "Connection successfully established"); //Comment out later
            return sqlite_conn1;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Connection 1 issue: " + e.getMessage() + "\n\n" + e.getStackTrace());
            return null;
        }
    }
    
        //Establishes the actual connection to the Members database
    private static Connection connectionDB2(){
        
        try{
            Class.forName("org.sqlite.JDBC");
            Connection sqlite_conn2 = DriverManager.getConnection("jdbc:sqlite:GetBibMembers.db"); //Note this
        //    JOptionPane.showMessageDialog(null, "Connection successfully established");
            return sqlite_conn2;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Connection 2 issue: " + e.getMessage() + "\n\n" + e.getStackTrace());
            return null;
        }
    }
    

    //returns all the user sources and the pre-defined sources
     public static ArrayList<GetBibSources> GetAllSources(){
            ArrayList<GetBibSources> sources = new ArrayList<>();
///////////////////////////////////////////
            Statement statement = null;
            Connection s_conn = connectionDB(); //Call the connection method
            ResultSet res;
////////////////////////////////////////////
            String sql = "SELECT * FROM Bibliography"; //Returns a data-set

            try{
                statement = s_conn.createStatement();
                res = statement.executeQuery(sql);
              
                ArrayList<GetBibSources> all_sources = new ArrayList<>();
                
                while(res.next()) //ADDING ALL THE PRE-DEFINED SOURCES FIRST
                {
                    GetBibSources newSources = new GetBibSources(res.getString("Authors"), res.getString("Title"), res.getString("Date_Year"), res.getString("City"), res.getString("Publisher"), res.getString("Comment"), res.getString("ISBN")); //calls the constructor
                    all_sources.add(newSources); // a list of Bibliography objects
                }
                
////////////////////////////////////////////////////ADDING ALL THE USER-DEFINED SOURCES/////////////////
                ArrayList<GetBibMember> tempMembers = GetAllUserMembers(); //returns all the members
                
                for (int s = 0; s < tempMembers.size(); s++) //for each user, get their sources
                {
                    ArrayList <GetBibSources> tempSources2 = GetUserSources(tempMembers.get(s).returnUsername());

                    for(int src2 = 0; src2 < tempSources2.size(); src2++){
                        all_sources.add(tempSources2.get(src2));
                    }
                }
                 s_conn.close();
                 return all_sources;
            }
            
            catch(Exception e){
                JOptionPane.showMessageDialog(null,"Problem getting all sources: \n\n" + e.getMessage() + "\n\n" + e.getStackTrace());
                return null;
                        }
            }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        ///  This method saves all the users created to a database
        /// </summary>
        /// <param name="members">A list of members</param>
        public static void saveUserInfo(List<GetBibMember> members){
            // We use these three SQLite objects:
            Statement statement = null;
            // open the connection:
            Connection s_conn = connectionDB2(); 

            // Let the SQLiteCommand object know our SQL-Query:
            try{
                for(int mem = 0; mem < members.size(); mem++){//string sql = "INSERT INTO GetBibMembers (Username) VALUES ('" + mem.Username +"' )";
                    String sql = "INSERT INTO GetBibMembers (Username, Password, Email, Security_Question, Answer, Time) VALUES ('" + members.get(mem).returnUsername() + "', '" + members.get(mem).returnPassword() + "', '" + members.get(mem).returnEmail() + "', '" + members.get(mem).returnQuestion() + "', '" + members.get(mem).returnAnswer() + "',  '" + members.get(mem).returnDate() + "')";
                        // Now lets execute the SQL
                    statement = s_conn.createStatement();
                    statement.execute(sql); //Does not return a dataset
                }
                statement.close();
                s_conn.close();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null,"Problem with saving user information" + e.getMessage() + "\n\n" + e.getStackTrace());
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Saves the user-defined sources
        /// </summary>
        /// <param name="src">a list of src</param>
        public static void saveUserDefinedSrc(ArrayList<GetBibSources> src, String tablename) {//
            Statement statement = null;
            Connection s_conn = connectionDB();
            
            try{
                // Let the SQLiteCommand object know our SQL-Query:
                for(int s = 0; s < src.size(); s++){//could include an if statement to determine which code to execute
                    String sql = "INSERT INTO " + tablename + " (Authors, Title, Date_Year, City, Publisher, Comment, ISBN) VALUES ('" + src.get(s).Authors() + "', '" + src.get(s).returnSourceTitle() + "', '" + src.get(s).Date() + "', '" + src.get(s).returnPlaceOfPub() + "', '" + src.get(s).returnPublisher() + "',  '" + src.get(s).returnCommentOnSrc() + "', '" + src.get(s).returnISBN() + "')";
                    // Now lets execute the   
                    statement = s_conn.createStatement();
                    statement.execute(sql); //Does not return a dataset
                }
                
                statement.close();
                s_conn.close();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null,"Problem with saving user-defined sources /n" + e.getMessage() + "\n" + e.getStackTrace());
            }
        }
        
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// this method retrieve all the sources from the user's database
        /// </summary>
        /// <param name="userNforDB">table name / username</param>
        /// <returns>a list of sources linked to the specified username</returns>
        public static ArrayList<GetBibSources> GetUserSources(String userNforDB){
            Statement statement = null;
            Connection s_conn = connectionDB(); //Call the connection method
            
            String sql = "SELECT * FROM " + userNforDB; //Returns a data-set
            
            ArrayList<GetBibSources> UserSources = new ArrayList<>();
            try{                
                statement = s_conn.createStatement();
                res = statement.executeQuery(sql);

                while (res.next()){
                    GetBibSources newSources = new GetBibSources(res.getString("Authors"), res.getString("Title"), res.getString("Date_Year"), res.getString("City"), res.getString("Publisher"), res.getString("Comment"), res.getString("ISBN")); //calls the constructor
                    UserSources.add(newSources); //
                }
                
                res.close();
                statement.close();
                s_conn.close();
            }
            catch (SQLException issue){
                JOptionPane.showMessageDialog(null,"There are no user-defined sources for your account \n Please create one first \n " + issue.getMessage());
            }
            return UserSources; //return the list
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        ///  This method creates a table linked to a user account after the account has been created
        /// </summary>
        /// <param name="userNforDB">the username of the account created. It is used as the name of the table</param>
        public static void createUserTable(String userNforDB){

            Connection s_conn = connectionDB(); //Call the connection method
            Statement statement = null;
            // Let the SQLiteCommand object know our SQL-Query:
            try{
                //string sql = "INSERT INTO GetBibMembers (Username) VALUES ('" + mem.Username +"' )";
                String sql = "CREATE TABLE " + userNforDB + " (Authors, Title, Date_Year, City, Publisher, Comment, ISBN)";
                // Now lets execute the SQL
                statement = s_conn.createStatement();
                statement.executeQuery(sql);
               //>>>>>>>>>>>>>>>>>>>>>>>>>.
                statement.close();
                s_conn.close();
            //Close Connection
            }
            catch(SQLException problem){
                JOptionPane.showMessageDialog(null,"Your personal library of sources was not created \n Please contact the GetBib-Team at (1800)Get-Bib \n\n \t StackTrace \n" + problem.getMessage());
            }
        }


        /// <summary>
        /// This method deletes a source from the user's database, by the user's request
        /// </summary>
        /// <param name="userNforDB">the table identification code. It also represents the username</param>
        /// <param name="ID">the sources index</param>
        public static boolean deleteUserSource(String userNforDB, String title){ /// //Deleting source in New Table for User Defined Settings
            // We use these three SQLite objects:
            Connection s_conn = connectionDB();  // open the connection:
            Statement statement;

            try{
              
                //string sql = "INSERT INTO GetBibMembers (Username) VALUES ('" + mem.Username +"' )";
                String sql = "DELETE FROM " + userNforDB + " WHERE Title='"+title+"'";
                
                statement = s_conn.createStatement();
                statement.execute(sql);
                //>>>>>>>>>>>>>>>>>>>>>>>>
                statement.close();
                s_conn.close();
                return true;
            }
            catch (SQLException sqlEx){
                JOptionPane.showMessageDialog(null,"Problem deleting user's sources: \n\n" +sqlEx.getMessage() + "\n\n" + sqlEx.getStackTrace());
                return false;
            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        /// <summary>
        /// returns a list of account created by GetBib users
        /// </summary>
        /// <returns>The list of accounts</returns>
        public static ArrayList<GetBibMember> GetAllUserMembers(){
           // int count = 0;
            Statement statement;
            Connection s_conn = connectionDB2();

             ArrayList<GetBibMember> UserMembers = new ArrayList<>();
            
            try{
                String sql = "SELECT * FROM GetBibMembers"; //Gets the dataset
                statement = s_conn.createStatement();
                res = statement.executeQuery(sql);
            //    res.beforeFirst(); //move the cursor right before the first row
                
                while(res.next()){ //while there is a row, 
                    GetBibMember newMember = new GetBibMember(); //calls the no-argument constructor
                    newMember.setUsername(res.getString("Username"));
                    newMember.setPassword(res.getString("Password"));
                    newMember.setEmail(res.getString("Email"));
                    newMember.setQuestion(res.getString("Security_Question"));
                    newMember.setAnswer(res.getString("Answer"));
                    newMember.setDate(res.getString("Time"));

                    UserMembers.add(newMember); 
                }
                res.close();  
                statement.close();
                s_conn.close(); //close the connection to the database
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null,"Note this: " + e.getMessage() +"\n\n"+ e.getStackTrace());
            }
            return UserMembers; //return the list
        }
}
