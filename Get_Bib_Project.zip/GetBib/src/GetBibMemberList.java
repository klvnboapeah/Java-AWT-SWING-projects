/***************************************
 * Advanced Programming semester long project
 * Fall 2013.
 ***************************************/
import java.util.*;

/**
 *
 * @author Kelvin B
 */
public class GetBibMemberList { //Note. no static class unlike in C# look it up
     static ArrayList<GetBibMember> members = new ArrayList<GetBibMember>(); //Generic type
        
        /// <summary>
        /// Returns a list of members
        /// </summary>
        /// <returns>The member list</returns>
        public static ArrayList<GetBibMember> returnList(){
            return members;
        }

        /// <summary>
        /// return the number of members
        /// </summary>
        public static int Count (){
            return members.size();
        }

        /// <summary>
        /// Adds the user's account to the list of users
        /// </summary>
        /// <param name="member"></param>
        public static void Add (GetBibMember member){
            members.add(member);
        }

        /// <summary>
        /// This method adds creates a member, and adds it to the member list
        /// </summary>
        /// <param name="UserStr"></param>
        /// <param name="PassStr"></param>
        /// <param name="EmailStr"></param>
        /// <param name="securityQuestionStr"></param>
        /// <param name="securityAnswerStr"></param>
        /// <param name="dateStr"></param>
        public static void Add (String UserStr, String PassStr, String EmailStr, String securityQuestionStr, String securityAnswerStr, String dateStr){
        GetBibMember g = new GetBibMember(UserStr, PassStr, EmailStr, securityQuestionStr, securityAnswerStr, dateStr);
        members.add(g);
    }
    
    
}
