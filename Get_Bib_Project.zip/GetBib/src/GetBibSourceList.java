
import java.util.*;

/***************************************
 * Advanced Programming semester long project
 * Fall 2013.
 ***************************************/

/**
 *
 * @author Kelvin B
 */
public class GetBibSourceList {
    static ArrayList<GetBibSources> sources = new ArrayList<GetBibSources>(); //In java, create an "ArrayList", in C# create a "List"

        public static ArrayList<GetBibSources> returnList(){
            return sources;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static ArrayList<GetBibSources> returnSourceList(){
            return sources;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static boolean clearSourceList(){
            sources.clear();
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        public static int Count(){
            return sources.size(); //"size()" instead of "Count" in C#
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="src"></param>
        public static void Add(GetBibSources src){
            sources.add(src);
        }
    
}
