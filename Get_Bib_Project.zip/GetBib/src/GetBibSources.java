
/***************************************
 * Advanced Programming semester long project
 * Fall 2013.
 ***************************************/

/**
 *
 * @author Kelvin B
 */
public class GetBibSources {
          //Fields
        private String generalAuthors;
        private String authorFirstName;
        private String authorLastName;
        private String secondAuthorFirstName;
        private String secondAuthorLastName;
        private String  sourceTitle;
        private String titleOfArticle;
        private String volumeEdition;
        private String date;
        private String placeOfPublication;
        private String numberOfPages;
        private String publisherORDataBase;
        private String Comment;
        public String isbn;

        /// <summary>
        /// Book source constructor (1)
        /// </summary>
        public GetBibSources() { } //no-argument constructor

        /// <summary>
        /// A book source constructor (2)
        /// </summary>
        /// <param name="authorFirstName">Author's first name</param>
        /// <param name="authorLastName">Author's last name</param>
        /// <param name="sourceTitle">Source titlr</param>
        /// <param name="titleOfArticle"></param>
        /// <param name="volumeEdition">volume or edition</param>
        /// <param name="date">date or year of publication</param>
        /// <param name="placeOfPublicaion">place of publication</param>
        /// <param name="numberOfPages">number of pages</param>
        /// <param name="publisherORDatabase">publisher</param>
        /// <param name="isbn">Source's ISBN number</param>
        public GetBibSources(String authorFirstName, String authorLastName, String sourceTitle, String titleOfArticle,String volumeEdition,
            String date, String placeOfPublicaion, String numberOfPages, String publisherORDatabase, String ISBN) //complete form
        { //A custom constructor
            this.authorFirstName = authorFirstName;
            this.authorLastName = authorLastName;
            this.sourceTitle = sourceTitle;
            this.titleOfArticle = titleOfArticle;
            this.volumeEdition = volumeEdition;
            this.date = date;
            this.placeOfPublication = placeOfPublicaion;
            this.numberOfPages = numberOfPages;
            this.publisherORDataBase = publisherORDatabase;
            this.isbn = ISBN;
        }

       /// <summary>
       /// Book source constructor (3)
       /// </summary>
       /// <param name="authorFirstName">Author's first name</param>
       /// <param name="authorLastName">Author's last name</param>
       /// <param name="sourceTitle">book source</param>
       /// <param name="date">date of publication</param>
       /// <param name="placeOfPublication">place of publication</param>
       /// <param name="publisherORDatabase">publisher</param>
       /// <param name="cmt">comment about the source</param>
       /// <param name="ISBN">ISBN number</param>
        public GetBibSources(String authorFirstName, String authorLastName, String sourceTitle, String date, String placeOfPublication, String publisherORDatabase, String cmt, String ISBN){
            this.authorFirstName = authorFirstName;
            this.authorLastName = authorLastName;
            this.sourceTitle = sourceTitle;
            this.date = date;
            this.placeOfPublication = placeOfPublication;
            this.publisherORDataBase = publisherORDatabase;
            this.isbn = ISBN;
        }

        /// <summary>
        /// Generalized constructor (4)
        /// </summary>
        /// <param name="allAuthors">all authors, without any format</param>
        /// <param name="title">source title</param>
        /// <param name="dateYear">date and year of publication</param>
        /// <param name="city">place of publication</param>
        /// <param name="publisher">publisher</param>
        /// <param name="cmt">comment any the book source</param>
        /// <param name="ISBN">ISBN number</param>
        public GetBibSources(String allAuthors, String title, String dateYear, String city, String publisher, String cmt, String ISBN){
            generalAuthors = allAuthors;
            sourceTitle = title;
            date = dateYear;
            placeOfPublication = city;
            publisherORDataBase = publisher;
            Comment = cmt;
            isbn = ISBN;
        }

        ///// <summary>
        ///// Constructor (5)
        ///// </summary>
        ///// <param name="authorFirstName">First author's first name</param>
        ///// <param name="authorLastName">First author's last name</param>
        ///// <param name="secondAuthorFirstName">Second author's first name</param>
        ///// <param name="secondAuthorLastName">Second author's last name</param>
        ///// <param name="sourceTitle">source title</param>
        ///// <param name="date">date or year of publication</param>
        ///// <param name="city">Place of publication</param>
        ///// <param name="publisher">publisher</param>
        ///// <param name="cmt">comment about the source</param>
        ///// <param name="ISBN">ISBN number</param>
        //public GetBibSources( string authorFirstName, string authorLastName, string secondAuthorFirstName, string secondAuthorLastName, string sourceTitle, string date, string city, string publisher, string cmt, string ISBN){
        //    this.authorFirstName = authorFirstName;
        //    this.authorLastName = authorLastName;
        //    this.secondAuthorFirstName = secondAuthorFirstName;
        //    this.secondAuthorLastName = secondAuthorLastName;
        //    this.sourceTitle = sourceTitle;
        //    this.date = date;
        //    this.placeOfPublication = city;
        //    this.Comment = cmt;
        //    this.isbn = ISBN;
        //}

        //    /// <summary>
        //    /// Book source constructor (6)
        //    /// </summary>
        //    /// <param name="authorFirstName">Author's first name</param>
        //    /// <param name="authorLastName">Author's last name</param>
        //    /// <param name="sourceTitle">book source</param>
        //    /// <param name="dateYear">date and year of publication</param>
        //    /// <param name="placeOfPublication">place of publication</param>
        //    /// <param name="publisherORDatabase">publisher</param>
        //    /// <param name="comment">comment</param>
        //    /// <param name="ISBN">ISBN number</param>
        //public GetBibSources(string authorFirstNam, string authorLastName, string sourceTitle, string dateYear, string placeOfPublication,
        //    string publisherORDatabase, string comment, string ISBN){
        //        this.authorFirstName = authorFirstNam;
        //        this.authorLastName = authorLastName;
        //        this.sourceTitle = sourceTitle;
        //        this.date = dateYear;
        //        this.placeOfPublication = placeOfPublication;
        //        this.publisherORDataBase = publisherORDatabase;
        //        this.Comment = comment;
        //        this.isbn = ISBN;
        //}
       
        /// <summary>
        /// Returns the author's first name
        /// </summary>
        public String AuthorFirstName(){
            return authorFirstName;
            }

        /// <summary>
        /// Set the author's first name
        /// </summary>
        /// <param name="str">The first name of the author</param>
        public void setAuthorFirstName(String str){
                authorFirstName = str;
            }
        
        /// <summary>
        /// Returns the publisher of the book source
        /// </summary>
        /// <returns>The specified book source publisher</returns>
        public String returnPublisher(){
            return publisherORDataBase;
        }

        /// <summary>
        /// Sets the publisher of the book source
        /// </summary>
        /// <param name="str">the new publisher</param>
        public void setPublisher(String str){
            publisherORDataBase = str;
        }
   
        /// <summary>
        /// return the any comment about the book source
        /// </summary>
        /// <returns>the comment</returns>
        public String returnCommentOnSrc(){
            return Comment;
        }

        /// <summary>
        /// Sets the comment about the book source
        /// </summary>
        /// <param name="str"></param>
        public void setCommentOnSrc(String str){
            Comment = str;
        }

        /// <summary>
        /// Returns the place of publication of the book source
        /// </summary>
        /// <returns>The place of publication</returns>
        public String returnPlaceOfPub(){
            return placeOfPublication;
        }
            
        /// <summary>
        /// Set the place of publication for the book source
        /// </summary>
        /// <param name="p"></param>
        public void setPlaceOfPub(String p){
                placeOfPublication = p;
        }

        /// <summary>
        /// Gets author's first name 
        /// </summary>
        public String FirstAuthorFirstName(){
            return authorFirstName;
        }
        
        //sets the author's first name 
        public void FirstAuthorFirstName(String value){
            authorFirstName = value;
        }

        /// <summary>
        ///  Gets the first author's last name
        /// </summary>
        public String AuthorLastName(){
                return authorLastName;
            }

        //sets the first author's last name
        public void AuthorLastName(String value){
            authorLastName = value;
        }
            
        

        /// <summary>
        ///  Gets the second author's first name
        /// </summary>
        public String SecondAuthorFirstName(){
                return secondAuthorFirstName;
            }
        
        //sets the second author's first name
        public void SecondAuthorFirstName(String value){
            secondAuthorLastName = value;
            }
        

        /// <summary>
        /// Gets or sets the author's last name
        /// </summary>
        public String SecondAuthorLastName(){
                return secondAuthorLastName;
        }
        
        public void SecondAuthorLastName(String value){
                secondAuthorLastName = value;
        }

        /// <summary>
        /// Sets the authors names
        /// </summary>
        public void Authors(String str){
            generalAuthors = str;
        }

        /// <summary>
        /// Returns the author's name
        /// </summary>
        /// <returns>Author's name</returns>
        public String Authors(){
            return generalAuthors;
        }


        /// <summary>
        /// Returns the book's title
        /// </summary>
        /// <returns>The book's title</returns>
        public String returnSourceTitle(){
            return sourceTitle;
            }

        /// <summary>
        /// Sets the book's title
        /// </summary>
        /// <param name="st">The title of the book</param>
        public void setSourceTitle(String st){
                sourceTitle = st;
            }
        

        /// <summary>
        /// Returns the book's volume or revision
        /// </summary>
        /// <returns>The volume or revision</returns>
        public String returnVolumeEdition(){
                return volumeEdition; 
        }

        /// <summary>
        /// Sets the volume of the book
        /// </summary>
        /// <param name="str">The volume or revision</param>
        public void setVolumeEdition(String str){
                volumeEdition = str;
            }
        


        /// <summary>
        /// Returns the time the book was made
        /// </summary>
        /// <returns>The time</returns>
        public String Date(){
            return date;
            }

        /// <summary>
        /// Set the time the book source was made
        /// </summary>
        /// <param name="d">the time</param>
        public void setDate(String d){
                date = d;
            }
        

        /// <summary>
        /// returns the image index of the book source
        /// </summary>
        /// <returns>The image index</returns>
         public String returnISBN(){ //Might have to edit this
                 return isbn;
            }

        /// <summary>
        /// Sets the ISBN for the book source
        /// </summary>
        /// <param name="str">the ISBN number</param>
         public void setISBN(String str){
             isbn = str;
         }

        /// <summary>
        /// sets the image index of the book source
        /// </summary>
        /// <param name="ss">the index</param>
        public void setImageIndex(String ss){
            isbn = ss;
            }

      /// <summary>
        /// For each book, the method formats the information about the book, and returns the formated information
      /// </summary>
      /// <returns>the formatted information about the book</returns>
        public String listBooks(){
            String format;
            format = generalAuthors + " " + sourceTitle + " " + date + " " + placeOfPublication + " " + publisherORDataBase + " " + Comment + " ISBN: " + isbn;
            return format;
        }
    
}
