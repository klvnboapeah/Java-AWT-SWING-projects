

/***************************************
 * Advanced Programming semester long project
 * Fall 2013.
 ***************************************/
import java.util.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
 import java.awt.event.ActionListener;

/**
 * @author Kelvin B
 */
public class GetBibValidation {
       private static String strPass = "", savePassword = "", saveUsername = "";
        public static String UserTableID; 

        //txtAuthors, txtTitle, txtPubYear, txtCity, txtPublisher
        public static boolean ValidationMethod2(JTextField textBox1, JTextField textBox2, JTextField textBox3, JTextField textBox4, JTextField textBox5)
        {
            boolean tf = false;
            if (textBox1.getText().isEmpty() == true && textBox2.getText().isEmpty() == true && textBox3.getText().isEmpty() == true && textBox4.getText().isEmpty() == true && textBox5.getText().isEmpty() == true)
            {
              //MessageBox.Show("All the fields are empty \n", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                textBox1.setBackground(Color.yellow);
                textBox2.setBackground(Color.yellow);
                textBox3.setBackground(Color.yellow);
                textBox4.setBackground(Color.yellow);
                textBox5.setBackground(Color.yellow);
                textBox1.requestFocus();
                return tf;
            }

            else if (textBox1.getText().isEmpty() == true)
            {
                //MessageBox.Show("Enter an author's name.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.setBackground(Color.yellow);
                textBox1.requestFocus();
                return tf;
            }

            else if (textBox2.getText().isEmpty() == true)
            {
                //MessageBox.Show("Enter a title.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.setBackground(Color.yellow);
                textBox2.requestFocus();
                return tf;
            }

            else if (textBox3.getText().isEmpty() == true)
            {
                //MessageBox.Show("Enter the year of publication.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox3.setBackground(Color.yellow);
                textBox3.requestFocus();
                return tf;
            }

            else if (textBox4.getText().isEmpty() == true)
            {
                //MessageBox.Show("Enter a city of publication.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox4.setBackground(Color.yellow);
                textBox4.requestFocus();
                return tf;
            }

            else if (textBox5.getText().isEmpty() == true){
                //MessageBox.Show("Enter a publisher.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.setBackground(Color.yellow);
                textBox5.requestFocus();
                return tf;
            }
            return tf;
        }

     
        /// <summary>
        /// 
        /// </summary>
        /// <param name="textBox1"></param>
        /// <param name="textBox2"></param>
        /// <param name="textBox3"></param>
        /// <param name="textBox4"></param>
        /// <param name="textBox5"></param>
        /// <returns></returns>
        public static boolean ValidationMethod(JTextField textBox1, JTextField textBox2, JTextField textBox3, JTextField textBox4, JTextField textBox5){
            boolean tf = false;
            if (textBox1.getText().isEmpty() == true && textBox2.getText().isEmpty() == true && textBox3.getText().isEmpty() == true && textBox4.getText().isEmpty() == true && textBox5.getText().isEmpty() == true){
                //MessageBox.Show("Enter a username \n" + " Enter a password \n", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                textBox1.setBackground(Color.YELLOW);
                textBox2.setBackground(Color.YELLOW);
                textBox3.setBackground(Color.YELLOW);
                textBox4.setBackground(Color.YELLOW);
                textBox5.setBackground(Color.YELLOW);
                textBox1.requestFocus();
                return tf;
            }

            else if (textBox1.getText().isEmpty() == true){
             //   MessageBox.Show("Enter a username", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.setBackground(Color.YELLOW);
                textBox1.requestFocus();
                textBox2.setText(""); //password
                textBox3.setText(""); //confirm password
                return tf;
            }

            else if (textBox2.getText().isEmpty() == true || textBox3.getText().isEmpty() == true){
              //  MessageBox.Show("Enter a password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.setBackground(Color.YELLOW);
                textBox3.setBackground(Color.YELLOW);
                textBox2.requestFocus();
                return tf;
            }

            else if (textBox4.getText().isEmpty() == true){
               // MessageBox.Show("Enter an email address", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox4.setBackground(Color.YELLOW);
                textBox4.requestFocus();
                return tf;
            }

            else if (textBox5.getText().isEmpty() == true){
                //MessageBox.Show("Enter an answer for the security question", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.setBackground(Color.YELLOW);;
                textBox5.requestFocus();
                return tf;
            }

            else if (isValidPassword(textBox2, textBox3) == true){
              //  saveUsername = textBox1.Text.Trim(); //have to extract the password to an xml or a text file
               // savePassword = textBox2.Text.Trim(); // have to extract the password to an xml or a text file
                tf = true;
                return tf;
            }
            return tf;
        }

        /// <summary>
        /// this method determines if the password and confirm password match
        /// </summary>
        /// <param name="textBox2">the password field</param>
        /// <param name="textBox3">the confirm password</param>
        /// <returns></returns>
        public static boolean isValidPassword(JTextField textBox2, JTextField textBox3){
            boolean tf = false;
            int numCount = 0, numAlphabet = 0, numSymbols = 0;
            String strTemp = ""; 
            ///////////////////////////////////////////////////////////////////////////////////
            strTemp = textBox2.getText();
            /////////////////////////////////////////////////////////////////////////////////
            for (int i = 0; i < strTemp.length(); i++){
                if (strTemp.charAt(i) == '0' || strTemp.charAt(i) == '1' || strTemp.charAt(i) == '2' || strTemp.charAt(i) == '3' || strTemp.charAt(i) == '3' || strTemp.charAt(i) == '4' || strTemp.charAt(i) == '5' ||
                    strTemp.charAt(i) == '6' || strTemp.charAt(i) == '7' || strTemp.charAt(i) == '8' || strTemp.charAt(i) == '9') // is a number
                    numCount++;

                if (strTemp.charAt(i) == 'a' || strTemp.charAt(i) == 'b' || strTemp.charAt(i) == 'c' || strTemp.charAt(i) == 'd' || strTemp.charAt(i) == 'e' || strTemp.charAt(i) == 'f' || strTemp.charAt(i) == 'g' || strTemp.charAt(i) == 'h' ||
                    strTemp.charAt(i) == 'i' || strTemp.charAt(i) == 'j' || strTemp.charAt(i) == 'k' || strTemp.charAt(i) == 'l' || strTemp.charAt(i) == 'm' || strTemp.charAt(i) == 'n' || strTemp.charAt(i) == 'o' || strTemp.charAt(i) == 'p' ||
                    strTemp.charAt(i) == 'q' || strTemp.charAt(i) == 'r' || strTemp.charAt(i) == 's' || strTemp.charAt(i) == 't' || strTemp.charAt(i) == 'u' || strTemp.charAt(i) == 'v' || strTemp.charAt(i) == 'w' || strTemp.charAt(i) == 'x' ||
                    strTemp.charAt(i) == 'y' || strTemp.charAt(i) == 'z' || strTemp.charAt(i) == 'A' || strTemp.charAt(i) == 'B' || strTemp.charAt(i) == 'C' || strTemp.charAt(i) == 'D' || strTemp.charAt(i) == 'E' || strTemp.charAt(i) == 'F' ||
                    strTemp.charAt(i) == 'G' || strTemp.charAt(i) == 'H' || strTemp.charAt(i) == 'I' || strTemp.charAt(i) == 'J' || strTemp.charAt(i) == 'K' || strTemp.charAt(i) == 'L' || strTemp.charAt(i) == 'M' || strTemp.charAt(i) == 'N' ||
                    strTemp.charAt(i) == 'O' || strTemp.charAt(i) == 'P' || strTemp.charAt(i) == 'Q' || strTemp.charAt(i) == 'R' || strTemp.charAt(i) == 'S' || strTemp.charAt(i) == 'T' || strTemp.charAt(i) == 'U' || strTemp.charAt(i) == 'V' ||
                    strTemp.charAt(i) == 'W' || strTemp.charAt(i) == 'X' || strTemp.charAt(i) == 'Y' || strTemp.charAt(i) == 'Z') // is a letter of the alphabet
                    numAlphabet++;

                if (strTemp.charAt(i) == '.' || strTemp.charAt(i) == ':' || strTemp.charAt(i) == ';' || strTemp.charAt(i) == '/' || strTemp.charAt(i) == ')' || strTemp.charAt(i) == '(')
                    numSymbols++;
            }

            if (numCount > 0 && numAlphabet > 0 && numSymbols > 0) //
                tf = true;


            ///do passwords match? fix it
            for (int t = 0; t < textBox2.getText().length(); t++){
                if (textBox2.getText().charAt(t) == textBox3.getText().charAt(t) == true) { }

                if (textBox2.getText().charAt(t) != textBox3.getText().charAt(t)){
                    //MessageBox.Show("Passwords do not match!", "Warning");
                    textBox2.setText("");
                    textBox3.setText("");
                    textBox2.setBackground(Color.YELLOW);
                    textBox3.setBackground(Color.YELLOW);;
                    textBox2.requestFocus();
                    t = textBox2.getText().length();
                }
            }


            if (numCount == 0){
                //MessageBox.Show("The password does not contain a number!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.setText("");
                textBox3.setText("");
                textBox2.setBackground(Color.YELLOW);
                textBox3.setBackground(Color.YELLOW);
                textBox2.requestFocus();
                return tf;
            }

            if (numAlphabet == 0){
                //MessageBox.Show("The password does not contain a letter!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.setText("");
                textBox3.setText("");
                textBox2.setBackground(Color.YELLOW);
                textBox3.setBackground(Color.YELLOW);
                textBox2.requestFocus();
                return tf;
            }

            if (numSymbols == 0){
                //MessageBox.Show("The password must contain at least one of (./,);:     ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.setText("");
                textBox3.setText("");
                textBox2.setBackground(Color.YELLOW);
                textBox3.setBackground(Color.YELLOW);
                textBox2.requestFocus();
                return tf;
            }
            return tf;
        }


        /// <summary>
        /// this method performs some validation on the username and password
        /// </summary>
        /// <param name="textBox1">the username field</param>
        /// <param name="textBox2">the password field</param>
        /// <returns></returns>
        public static boolean ValidationMethod(JTextField textBox1, JTextField textBox2){
            boolean tf = false;

            if (textBox1.getText().isEmpty() == true && textBox2.getText().isEmpty() == true){
                JOptionPane.showMessageDialog(null, "Enter a username \n" + " Enter a password");
                textBox1.setBackground(Color.YELLOW);
                textBox2.setBackground(Color.YELLOW);
                textBox1.requestFocus();
                return tf;
            }

            else if (textBox1.getText().isEmpty() == true){
                JOptionPane.showMessageDialog(null, "Enter a username");
                textBox1.setBackground(Color.YELLOW);
                textBox2.setBackground(Color.YELLOW);
                textBox1.setText("");
                textBox2.setText("");
                textBox1.requestFocus();
                return tf;
            }

            else if (textBox2.getText().isEmpty() == true){
                 JOptionPane.showMessageDialog(null, "Enter a password");
                textBox2.setBackground(Color.YELLOW);
                textBox2.setText("");
                textBox2.requestFocus();
                return tf;
            }

            else if (isValidPassword(textBox2) == true){
//
//               // savePassword = textBox2.Text.Trim(); // have to extract the password to an xml or a text file
//              //  saveUsername = textBox1.Text.Trim(); //have to extract the password to an xml or a text file
            }
            tf = true;
            return tf;
        }

        /// <summary>
        /// this method determines if the password is valid
        /// </summary>
        /// <param name="textBox2">the password field</param>
        /// <returns>true, if the password is valid, or false if otherwise</returns>
        public static boolean isValidPassword(JTextField textBox2){
            int numCount = 0, numAlphabet = 0, numSymbols = 0;
            String strTemp = "";
            boolean tf = false;
            ///////////////////////////////////////////////////////////////////////////////////
            strTemp = textBox2.getText();
            for (int i = 0; i < strTemp.length(); i++){
                if (strTemp.charAt(i) == '0' || strTemp.charAt(i) == '1' || strTemp.charAt(i) == '2' || strTemp.charAt(i) == '3' || strTemp.charAt(i) == '3' || strTemp.charAt(i) == '4' || strTemp.charAt(i) == '5' ||
                    strTemp.charAt(i) == '6' || strTemp.charAt(i) == '7' || strTemp.charAt(i) == '8' || strTemp.charAt(i) == '9') // is a number
                    numCount++;

                if (strTemp.charAt(i) == 'a' || strTemp.charAt(i) == 'b' || strTemp.charAt(i) == 'c' || strTemp.charAt(i) == 'd' || strTemp.charAt(i) == 'e' || strTemp.charAt(i) == 'f' || strTemp.charAt(i) == 'g' || strTemp.charAt(i) == 'h' ||
                    strTemp.charAt(i) == 'i' || strTemp.charAt(i) == 'j' || strTemp.charAt(i) == 'k' || strTemp.charAt(i) == 'l' || strTemp.charAt(i) == 'm' || strTemp.charAt(i) == 'n' || strTemp.charAt(i) == 'o' || strTemp.charAt(i) == 'p' ||
                    strTemp.charAt(i) == 'q' || strTemp.charAt(i) == 'r' || strTemp.charAt(i) == 's' || strTemp.charAt(i) == 't' || strTemp.charAt(i) == 'u' || strTemp.charAt(i) == 'v' || strTemp.charAt(i) == 'w' || strTemp.charAt(i) == 'x' ||
                    strTemp.charAt(i) == 'y' || strTemp.charAt(i) == 'z' || strTemp.charAt(i) == 'A' || strTemp.charAt(i) == 'B' || strTemp.charAt(i) == 'C' || strTemp.charAt(i) == 'D' || strTemp.charAt(i) == 'E' || strTemp.charAt(i) == 'F' ||
                    strTemp.charAt(i) == 'G' || strTemp.charAt(i) == 'H' || strTemp.charAt(i) == 'I' || strTemp.charAt(i) == 'J' || strTemp.charAt(i) == 'K' || strTemp.charAt(i) == 'L' || strTemp.charAt(i) == 'M' || strTemp.charAt(i) == 'N' ||
                    strTemp.charAt(i) == 'O' || strTemp.charAt(i) == 'P' || strTemp.charAt(i) == 'Q' || strTemp.charAt(i) == 'R' || strTemp.charAt(i) == 'S' || strTemp.charAt(i) == 'T' || strTemp.charAt(i) == 'U' || strTemp.charAt(i) == 'V' ||
                    strTemp.charAt(i) == 'W' || strTemp.charAt(i) == 'X' || strTemp.charAt(i) == 'Y' || strTemp.charAt(i) == 'Z') // is a letter of the alphabet
                    numAlphabet++;

                if (strTemp.charAt(i) == '.' || strTemp.charAt(i) == ':' || strTemp.charAt(i) == ';' || strTemp.charAt(i) == '/' || strTemp.charAt(i) == ')' || strTemp.charAt(i) == '(')
                    numSymbols++;
            }

            if (numCount == 0){
                JOptionPane.showMessageDialog(null,"The password does not contain a number!");
                textBox2.setText("");
                textBox2.requestFocus();
                textBox2.setBackground(Color.yellow);
                return tf;
            }

            if (numAlphabet == 0){
                JOptionPane.showMessageDialog(null, "The password does not contain a letter!");
                textBox2.setText("");
                textBox2.requestFocus();
                textBox2.setBackground(Color.yellow);
                return tf;
            }

            if (numSymbols == 0){
                JOptionPane.showMessageDialog(null, "The password must contain at least one of (./,);: ");
                //JOptionPane.showOptionDialog(textBox2, tf, strTemp, numCount, numCount, null, os, tf)
                textBox2.setText("");
                textBox2.requestFocus();
                textBox2.setBackground(Color.yellow);
                return tf;
            }
            tf = true; //then return
            return tf;
        }

        /// <summary>
        /// this method adds a member to the list of members
        /// </summary>
        /// <param name="member">a member</param>
        /// <param name="members">the list of members</param>
        /// <returns></returns>
        public static boolean isGetBibDataSaved(GetBibMember member, ArrayList<GetBibMember> members){
            boolean tf = false;
            members.add(member); //In java "add", in C# "Add"


            return tf;
        }

        /// <summary>
        /// Look for the user's account in the database
        /// </summary>
        /// <param name="str1">username</param>
        /// <param name="st2">password</param>
        /// <returns>true, if the account is found, false if otherwise</returns>
        public static boolean LookUpUser(String str1, String str2){
            boolean tf = false;
            ArrayList<GetBibMember> mems = GetBibMemberClassDB.GetAllUserMembers(); // store all the members for now
            ///compare strings with each objects strings
            for (int compare = 0; compare < mems.size(); compare++) //In java "size()". in C# "Count" 
            {
                if (str1.equals(mems.get(compare).returnUsername()) && str2.equals(mems.get(compare).returnPassword())){
                    tf = true;
                    UserTableID = str1;
                    compare = mems.size();
                }
            }
            return tf;
        }

        /// <summary>
        /// this method search for the user given the email, security question, and security question's answer 
        /// </summary>
        /// <param name="email">email address</param>
        /// <param name="securQ">security question</param>
        /// <param name="securAns">security question answer</param>
        /// <returns>the user object</returns>
        public static void LookUpUser2(String email, String securQ, String securAns){
            ArrayList<GetBibMember> mems2 = GetBibMemberClassDB.GetAllUserMembers(); // store all the members for now
            ///compare strings with each object strings
           
            for(int compare2 = 0; compare2 < mems2.size(); compare2++){
                if (email == mems2.get(compare2).returnEmail() & securQ == mems2.get(compare2).returnQuestion() & securAns == mems2.get(compare2).returnAnswer()){
                  //  frmForgot.memberForgotten = mems2.get(compare2);
                    //TT = compare2; //temporary holds the index of the object in the list
                    compare2 = mems2.size();
                }
            }
        }

        /// <summary>
        /// this method returns the table's identification for this user
        /// </summary>
        /// <returns>the table name</returns>
        public static String returnUserTableID(){
            return UserTableID;
        }

        /// <summary>
        /// Sets the table identification for this user
        /// </summary>
        /// <param name="str">the username as the table's name</param>
        public static void setUserTableID(String str){
            UserTableID = str;
        }

        /// <summary>
        /// this method performs some validation on the text fields given
        /// </summary>
        /// <param name="textBox1"></param>
        /// <param name="textBox2"></param>
        /// <param name="textBox3"></param>
        /// <param name="textBox4"></param>
        /// <param name="textBox5"></param>
        /// <param name="textBox6"></param>
        /// <returns></returns>
        public static boolean isGetBibDataSaved(JTextField textBox1, JTextField textBox2, JTextField textBox3, JTextField textBox4, JComboBox cb, JTextField textBox6)
        {
            boolean tf = false;
            int authorNameCounter = 0;

            if (textBox1.getText().isEmpty() == false && textBox2.getText().isEmpty() == false && textBox3.getText().isEmpty() == false && textBox4.getText().isEmpty() == false && cb.getSelectedIndex()== -1) //sixth field is not needed since it is just a comment
            {
                String msg = "This form contains unsaved data. \n\n" +
                "Do you want to save it?";

//                DialogResult buttonpressed =
//                    MessageBox.Show(msg, "User",
//                    MessageBoxButtons.YesNoCancel,
//                    MessageBoxIcon.Warning);

//                if (buttonpressed == DialogResult.Yes){
//                    tf = true;
//                }
            }
            return tf;
        }

        ///// <summary>
        /////  this method determines if the entries in these fields are valid
        ///// </summary>
        ///// <param name="textBox1">username field</param>
        ///// <param name="textBox2">password field</param>
        ///// <param name="textBox3">confirm password field</param>
        ///// <param name="textBox4">email field</param>
        ///// <param name="listbox">security question</param>
        ///// <param name="textBox5">answer field</param>
        ///// <returns></returns>
        public static boolean isGetBibDataSaveD(JTextField textBox1, JTextField textBox2, JTextField textBox3, JTextField textBox4, JTextField textBox5, JTextField textBox6)
        {//                                                               username              password            confirm password     email                   question                    answer
            boolean tf = false;

            if (textBox1.getText().isEmpty() == false && textBox2.getText().isEmpty() == false && textBox3.getText().isEmpty() == false && textBox4.getText().isEmpty() == false && textBox5.getText().isEmpty() == false)
            {
                String message = "This form contains unsaved data. \n\n" +
                    "Do you want to save it?";
                
                int button = JOptionPane.showConfirmDialog(null,"" + message, "User", JOptionPane.YES_NO_CANCEL_OPTION);

                if (button == 0)//yes
                {
                    if (GetBibValidation.ValidationMethod(textBox1, textBox2, textBox3, textBox4, textBox5) == true)
                        tf = true;

                    return tf;
                }
            }
            return tf;
        }

        /// <summary>
        /// Based on the item selected, this method returns an image associated with the item
        /// </summary>
        /// <param name="lst">book source's list</param>
        /// <param name="ss">the ISBN</param>
        /// <returns>the image which corresponds to the specified ISBN</returns>
        public static Image GetImageforItem(ArrayList<GetBibSources> lst, String ss){
            Image src = null;
            String word = "";
            for (int p = ss.length() - 1; p > -1; p--)
            { //First find the ISBN number, thence...
                if (ss.charAt(p) != ' ')
                    word = ss.charAt(p) + word;
            }

            try {
                if (word != ""){
                    ImageIcon ImageIcon = new ImageIcon("picThumbnail\\"+word+".jpg"); //NOTE THIS. Setting the icon for the application
                    src = ImageIcon.getImage();///
                }
                  
                if (word == ""){
                    ImageIcon ImageIcon = new ImageIcon("coming_soon.jpg"); //NOTE THIS. Setting the icon for the application
                    src = ImageIcon.getImage();///
                }
            }
            catch (Exception problem){
                JOptionPane.showMessageDialog(null,"Cannot find the image. \n Contact the GetBib-Team \n" + problem.getMessage());
            }
            return src;
        }
    
}
