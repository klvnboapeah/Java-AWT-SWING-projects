/***************************************
 * Advanced Programming semester long project
 * Fall 2013.
 ***************************************/

/**
 *
 * @author Kelvin B
 */
public class MLAFormatClass {
      /// <summary>
        /// the method creates the MLA format for the book source
        /// </summary>
        /// <param name="src">the book source</param>
        /// <returns>the formatted MLA</returns>
        public static String createMLAFormat(GetBibSources src){
            String s = "";
            s = src.Authors() + ". " + src.returnSourceTitle() + ". " + src.returnPlaceOfPub() + ": " + src.returnPublisher() + ", " + src.Date() + ". Print";
            return s;
        }
}
