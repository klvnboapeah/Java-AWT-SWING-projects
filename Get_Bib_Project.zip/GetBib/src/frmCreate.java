import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.InputMethodListener;
import javax.swing.*;
import java.util.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kelvin B
 */
public class frmCreate extends JFrame{
    //Date time = new Date();
    DefaultTableModel model2 = null;//Class scope
    static boolean T = false; //Note
    /**
     * Creates new form frmCreate
     */
    public frmCreate() {
        initComponents();
        jCreateBibPanel.setEnabled(false);
        jBibFormatPanel.setEnabled(false);
        AccountFormEnabler();
        init();
        
    }
    
    //called by the guest button
    public frmCreate(boolean T){
        if (T == true){
            initComponents();
            jAccPanel.setEnabled(false);
            model2 = (DefaultTableModel)GetBibTable1.getModel(); //Very important technique        
            rdoAPA.setSelected(true);
            fillBookSourceJTable2(); //note this
            GuestEnabler();
            init();
            btnBack1.requestFocus();
            }
    }
    
    //enables the creates a bibliography form, and disables the account form
    private void GuestEnabler(){
        //Enable createbib
        jCreateBibPanel.setEnabled(true);
        jBibFormatPanel.setEnabled(true);
        rdoAPA.setEnabled(true);
        rdoMLA.setEnabled(true);
        GetBibTable1.setEnabled(true);
        btnNext.setEnabled(true);
        btnBack1.setEnabled(true);
        txtSearch.setEnabled(true);
        lbSearch.setEnabled(true);
        
        //Disable accbib
        jAccPanel.setEnabled(false);
        txtUsername.setEnabled(false);
        txtPassword.setEnabled(false);
        txtConfirmPassword.setEnabled(false);
        txtEmail.setEnabled(false);
        cboSecurityQ2.setEnabled(false);
        txtAnswer.setEnabled(false);
        btnSubmit.setEnabled(false);
        btnBack.setEnabled(false);
    }
    
    //disables the account form, and enables the create bibliography form
    private void AccountFormEnabler(){
                //Enable accbib
        jAccPanel.setEnabled(true);
        txtUsername.setEnabled(true);
        txtPassword.setEnabled(true);
        txtConfirmPassword.setEnabled(true);
        txtEmail.setEnabled(true);
        cboSecurityQ2.setEnabled(true);
        txtAnswer.setEnabled(true);
        btnSubmit.setEnabled(true);
        btnBack.setEnabled(true);
        
        //Disable createbibForm
        jCreateBibPanel.setEnabled(false);
        jBibFormatPanel.setEnabled(false);
        rdoAPA.setEnabled(false);
        rdoMLA.setEnabled(false);
        GetBibTable1.setEnabled(false);
        btnNext.setEnabled(false);
        btnBack1.setEnabled(false);
        txtSearch.setEnabled(false);
        lbSearch.setEnabled(false);
    }
    
    
    ArrayList<GetBibSources> bookSrcs = null; //class scope
    
    //Fills the table with sources, both user-defined and pre-defined
    private void fillBookSourceJTable2(){   
          if(model2.getRowCount() > 0){

            int f = model2.getRowCount();
            f--;
            while(f > -1){ //Note this technique
                model2.removeRow(f);
                GetBibTable1.revalidate();
                f--;
                
            }
        }
          if(bookSrcs == null){
              bookSrcs = GetBibMemberClassDB.GetAllSources(); // store all the sources for now; // store all the sources for now. //Might have to make this static
          }

        for(int src = 0; src < bookSrcs.size(); src++){
            model2.addRow(new Object[]{bookSrcs.get(src).Authors(), bookSrcs.get(src).returnSourceTitle(), bookSrcs.get(src).Date(), bookSrcs.get(src).returnPlaceOfPub(), bookSrcs.get(src).returnPublisher(), bookSrcs.get(src).returnCommentOnSrc(), bookSrcs.get(src).returnISBN()}); //     
            }
          //  bookSrcs.clear(); //"clear()" instead of Clear() in C#
        }
    
    ////Fills the table with the given list of book sources
    private void fillBookSourceJTable2(ArrayList<GetBibSources> newL){
        for(int d = model2.getRowCount() - 1; d > -1; d--){
            model2.removeRow(d);
            GetBibTable1.revalidate();
        }
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
         
         int a = 0; //method scope
         while(a < newL.size()){
            model2.addRow(new Object[]{newL.get(a).Authors(), newL.get(a).returnSourceTitle(), newL.get(a).Date(), newL.get(a).returnPlaceOfPub(), newL.get(a).returnPublisher(), newL.get(a).returnCommentOnSrc(), newL.get(a).returnISBN()}); //  
            T = true; //sets the flag variable to true, in order to determine which method shows the picture
            a++;
         }
//           bookSrcs.clear(); //"clear()" instead of Clear() in C#

    }
    
    //does some initialization
        private void init(){//Internal code that sets up the frame
            setLocationRelativeTo(null); //centers the frame
            setVisible(true);
            ImageIcon ImageIcon = new ImageIcon("favicon.jpg"); //NOTE THIS. Setting the icon for the application
            Image Image = ImageIcon.getImage();///
            this.setIconImage(Image);///
            ///////////////////////////////////////////////////////////////////
            buttonGroup1.add(rdoAPA); //APA radio-button added to the group button
            buttonGroup1.add(rdoMLA); //MLA radio-button added to the group button
        }
        
        
        
        /// this method does the actual search for the book
        private void searchSource(String str, ArrayList<GetBibSources> srclist){ 
            
            for(int d = model2.getRowCount() - 1; d > -1; d--){
                model2.removeRow(d);
                GetBibTable1.revalidate();
            }
            
            ArrayList<GetBibSources> newList = new ArrayList<>(); //create a new list with the matches we want
            
            for(int r = 0; r < srclist.size(); r++){ //take a single book, and for that book get the author, and compare each character in the author's name

                int alphacounter = 0;
                for(int s = 0; s < str.length(); s++){
                    if(srclist.get(r).Authors().charAt(s) == str.charAt(s) || srclist.get(r).returnSourceTitle().charAt(s) == str.charAt(s)){
                        alphacounter++;
                    }
                }
                if (alphacounter == str.length()){ //where each character passed..
                    newList.add(srclist.get(r));
                }
            }
             fillBookSourceJTable2(newList); //overloaded
        }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jMainPanel = new javax.swing.JPanel();
        lbExit = new javax.swing.JLabel();
        jAccPanel = new javax.swing.JPanel();
        txtUsername = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        lbUsername = new javax.swing.JLabel();
        lbPassword = new javax.swing.JLabel();
        lbConfirmPassword = new javax.swing.JLabel();
        lbEmail = new javax.swing.JLabel();
        lbSecurityQ2 = new javax.swing.JLabel();
        cboSecurityQ2 = new javax.swing.JComboBox();
        txtAnswer = new javax.swing.JTextField();
        lbAnswer = new javax.swing.JLabel();
        btnSubmit = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        txtPassword = new javax.swing.JPasswordField();
        txtConfirmPassword = new javax.swing.JPasswordField();
        jCreateBibPanel = new javax.swing.JPanel();
        btnBack1 = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        jBibFormatPanel = new javax.swing.JPanel();
        rdoAPA = new javax.swing.JRadioButton();
        rdoMLA = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        GetBibTable1 = new javax.swing.JTable();
        txtSearch = new javax.swing.JTextField();
        lbSearch = new javax.swing.JLabel();
        lbPreview = new javax.swing.JLabel();
        lbPreviewPic = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 128, 0));
        setName("frmCreate"); // NOI18N
        setUndecorated(true);

        jMainPanel.setBackground(new java.awt.Color(255, 128, 0));
        jMainPanel.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        jMainPanel.setPreferredSize(new java.awt.Dimension(938, 610));

        lbExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon_LiveForensics.jpg"))); // NOI18N
        lbExit.setToolTipText("closes application");
        lbExit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbExit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbExitMouseClicked(evt);
            }
        });

        jAccPanel.setBackground(new java.awt.Color(255, 128, 0));
        jAccPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Create Account", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Microsoft Sans Serif", 1, 12), new java.awt.Color(0, 0, 0))); // NOI18N
        jAccPanel.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        jAccPanel.setName("frmCreatePanel2"); // NOI18N
        jAccPanel.setPreferredSize(new java.awt.Dimension(252, 328));

        txtUsername.setToolTipText("enter username here");

        txtEmail.setToolTipText("enter email here");

        lbUsername.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        lbUsername.setText("Username:");
        lbUsername.setToolTipText("click to give field focus");
        lbUsername.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbUsernameMouseClicked(evt);
            }
        });

        lbPassword.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        lbPassword.setText("Password:");
        lbPassword.setToolTipText("click to give field focus");
        lbPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbPasswordMouseClicked(evt);
            }
        });

        lbConfirmPassword.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        lbConfirmPassword.setText("Confirm: ");
        lbConfirmPassword.setToolTipText("click to give field focus");
        lbConfirmPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbConfirmPasswordMouseClicked(evt);
            }
        });

        lbEmail.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        lbEmail.setText("Email:");
        lbEmail.setToolTipText("click to give field focus");
        lbEmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbEmailMouseClicked(evt);
            }
        });

        lbSecurityQ2.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        lbSecurityQ2.setText("Security Question:");
        lbSecurityQ2.setToolTipText("click here to give focus");
        lbSecurityQ2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbSecurityQ2MouseClicked(evt);
            }
        });

        cboSecurityQ2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Choose one", "What is your favorite color?", "Who is your best childhood friend?", "What is the name of your favorite pet?", "What is your mothers maiden name?" }));

        txtAnswer.setToolTipText("enter answer here");

        lbAnswer.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        lbAnswer.setText("Answer:");
        lbAnswer.setToolTipText("click here to give field focus");
        lbAnswer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbAnswerMouseClicked(evt);
            }
        });

        btnSubmit.setBackground(new java.awt.Color(255, 128, 0));
        btnSubmit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12)); // NOI18N
        btnSubmit.setText("Submit");
        btnSubmit.setToolTipText("refresh the form");
        btnSubmit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSubmit.setPreferredSize(new java.awt.Dimension(75, 23));
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        btnBack.setBackground(new java.awt.Color(255, 128, 0));
        btnBack.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12)); // NOI18N
        btnBack.setText("Back");
        btnBack.setToolTipText("refresh the form");
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.setPreferredSize(new java.awt.Dimension(75, 23));
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        txtPassword.setToolTipText("enter password here");

        txtConfirmPassword.setToolTipText("enter confirm password here");

        javax.swing.GroupLayout jAccPanelLayout = new javax.swing.GroupLayout(jAccPanel);
        jAccPanel.setLayout(jAccPanelLayout);
        jAccPanelLayout.setHorizontalGroup(
            jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jAccPanelLayout.createSequentialGroup()
                .addComponent(lbSecurityQ2)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jAccPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jAccPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jAccPanelLayout.createSequentialGroup()
                        .addComponent(lbUsername)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jAccPanelLayout.createSequentialGroup()
                        .addGap(0, 6, Short.MAX_VALUE)
                        .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jAccPanelLayout.createSequentialGroup()
                                .addComponent(lbEmail)
                                .addGap(18, 18, 18)
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jAccPanelLayout.createSequentialGroup()
                                .addComponent(lbAnswer)
                                .addGap(18, 18, 18)
                                .addComponent(txtAnswer, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jAccPanelLayout.createSequentialGroup()
                                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jAccPanelLayout.createSequentialGroup()
                                        .addComponent(lbConfirmPassword)
                                        .addGap(18, 18, 18))
                                    .addGroup(jAccPanelLayout.createSequentialGroup()
                                        .addComponent(lbPassword)
                                        .addGap(18, 18, 18)))
                                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(cboSecurityQ2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jAccPanelLayout.setVerticalGroup(
            jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jAccPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbUsername))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbPassword))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbConfirmPassword))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbEmail))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbSecurityQ2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cboSecurityQ2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAnswer, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbAnswer))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(jAccPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jCreateBibPanel.setBackground(new java.awt.Color(255, 128, 0));
        jCreateBibPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Create Bibliograhpy | Choose a book", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Microsoft Sans Serif", 1, 12), new java.awt.Color(0, 0, 0))); // NOI18N
        jCreateBibPanel.setPreferredSize(new java.awt.Dimension(672, 564));
        jCreateBibPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBack1.setBackground(new java.awt.Color(255, 128, 0));
        btnBack1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12)); // NOI18N
        btnBack1.setText("Back");
        btnBack1.setToolTipText("back to login");
        btnBack1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack1.setPreferredSize(new java.awt.Dimension(75, 23));
        btnBack1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack1ActionPerformed(evt);
            }
        });
        jCreateBibPanel.add(btnBack1, new org.netbeans.lib.awtextra.AbsoluteConstraints(508, 562, -1, -1));

        btnNext.setBackground(new java.awt.Color(255, 128, 0));
        btnNext.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12)); // NOI18N
        btnNext.setText("Next");
        btnNext.setToolTipText("show print preview form");
        btnNext.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnNext.setPreferredSize(new java.awt.Dimension(75, 23));
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });
        jCreateBibPanel.add(btnNext, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 562, -1, -1));

        jBibFormatPanel.setBackground(new java.awt.Color(255, 128, 0));
        jBibFormatPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Bibliography Format", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Microsoft Sans Serif", 1, 12), new java.awt.Color(0, 0, 0))); // NOI18N
        jBibFormatPanel.setPreferredSize(new java.awt.Dimension(168, 100));

        rdoAPA.setBackground(new java.awt.Color(255, 128, 0));
        rdoAPA.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        rdoAPA.setSelected(true);
        rdoAPA.setText("APA");
        rdoAPA.setToolTipText("American Psychological Association. For example: John Smith (2013). Intro To C# (2nd ed.). Long Island, NY:");
        rdoAPA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        rdoMLA.setBackground(new java.awt.Color(255, 128, 0));
        rdoMLA.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        rdoMLA.setText("MLA");
        rdoMLA.setToolTipText("Modern Language Association. For example: Smith, John. Long Island, NY: Publishing company, 2013.");
        rdoMLA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        rdoMLA.setName("rdoMLA"); // NOI18N

        javax.swing.GroupLayout jBibFormatPanelLayout = new javax.swing.GroupLayout(jBibFormatPanel);
        jBibFormatPanel.setLayout(jBibFormatPanelLayout);
        jBibFormatPanelLayout.setHorizontalGroup(
            jBibFormatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jBibFormatPanelLayout.createSequentialGroup()
                .addContainerGap(53, Short.MAX_VALUE)
                .addGroup(jBibFormatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdoMLA)
                    .addComponent(rdoAPA))
                .addGap(50, 50, 50))
        );
        jBibFormatPanelLayout.setVerticalGroup(
            jBibFormatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jBibFormatPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rdoAPA)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rdoMLA)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jCreateBibPanel.add(jBibFormatPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 496, -1, -1));

        GetBibTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12)); // NOI18N
        GetBibTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Author", "Source Title", "Date of Publication", "Place of Publication", "Publisher", "Comment", "ISBN"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        GetBibTable1.setGridColor(new java.awt.Color(255, 255, 255));
        GetBibTable1.setName("GetBibTable1"); // NOI18N
        GetBibTable1.setSelectionBackground(new java.awt.Color(102, 0, 102));
        GetBibTable1.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        GetBibTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(GetBibTable1);
        GetBibTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        jCreateBibPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 63, 668, -1));

        txtSearch.setFont(new java.awt.Font("Microsoft Sans Serif", 3, 12)); // NOI18N
        txtSearch.setForeground(new java.awt.Color(153, 153, 153));
        txtSearch.setText("Search for Sources");
        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtSearchFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtSearchFocusLost(evt);
            }
        });
        txtSearch.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtSearchInputMethodTextChanged(evt);
            }
        });
        jCreateBibPanel.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(458, 17, 216, 35));

        lbSearch.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbSearchMouseClicked(evt);
            }
        });
        jCreateBibPanel.add(lbSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(414, 17, -1, 35));

        lbPreview.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lbPreview.setText("PREVIEW");

        lbPreviewPic.setText("Picture goes here");
        lbPreviewPic.setPreferredSize(new java.awt.Dimension(192, 212));

        javax.swing.GroupLayout jMainPanelLayout = new javax.swing.GroupLayout(jMainPanel);
        jMainPanel.setLayout(jMainPanelLayout);
        jMainPanelLayout.setHorizontalGroup(
            jMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jMainPanelLayout.createSequentialGroup()
                .addGroup(jMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jMainPanelLayout.createSequentialGroup()
                        .addGroup(jMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jMainPanelLayout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(lbPreviewPic, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jMainPanelLayout.createSequentialGroup()
                                .addGap(87, 87, 87)
                                .addComponent(lbPreview)))
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jMainPanelLayout.createSequentialGroup()
                        .addComponent(jAccPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jMainPanelLayout.createSequentialGroup()
                        .addGap(0, 648, Short.MAX_VALUE)
                        .addComponent(lbExit))
                    .addComponent(jCreateBibPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 680, Short.MAX_VALUE)))
        );
        jMainPanelLayout.setVerticalGroup(
            jMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jMainPanelLayout.createSequentialGroup()
                .addComponent(lbExit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jMainPanelLayout.createSequentialGroup()
                        .addComponent(jAccPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addComponent(lbPreview)
                        .addGap(4, 4, 4)
                        .addComponent(lbPreviewPic, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jCreateBibPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jMainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jMainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 652, Short.MAX_VALUE)
        );

        getAccessibleContext().setAccessibleName("frmCreate");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //This is the event handler for the exit button.
    //It closes the application when clicked
    private void lbExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbExitMouseClicked
        int choice = JOptionPane.showConfirmDialog(this, "Close the application?", null, JOptionPane.OK_CANCEL_OPTION);
        if(choice == 0){
            System.exit(0);
        }
    }//GEN-LAST:event_lbExitMouseClicked

    //This is the event handler for the submit button
    // It submits the account created to the database
    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSubmitActionPerformed

    //This is the event handler for the back button
    //It displays the login form to the user///////////////////////////////////////
    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false); //make the current form invisible
        new frmLogIn().setVisible(true); //make this form visible
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnBack1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack1ActionPerformed
        this.setVisible(false); //make the current form invisible
        new frmLogIn().setVisible(true); //make this form visible
    }//GEN-LAST:event_btnBack1ActionPerformed

    //This eventhandler displays the print form, and constructs the appriopriate bibliography, based on the user's choices
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        int[] selectedRowIndx = GetBibTable1.getSelectedRows(); //returns an integer array, containing the index of all selected rows

           model2 = (DefaultTableModel)GetBibTable1.getModel();
            ArrayList<GetBibSources> tempSrcList = new ArrayList<>();

            for(int i = 0; i < selectedRowIndx.length; i++){//  foreach ( ListViewItem item in checkedItems ){ //creates objects from the string information, and adds them to the list of objects, which is later passed to the next form
                GetBibSources tempSrc = new GetBibSources();
                tempSrc.Authors((String) model2.getValueAt(selectedRowIndx[i], 0)); //R x C
                tempSrc.setSourceTitle((String) model2.getValueAt(selectedRowIndx[i], 1));
                tempSrc.setDate((String) model2.getValueAt(selectedRowIndx[i], 2));
                tempSrc.setPlaceOfPub((String) model2.getValueAt(selectedRowIndx[i], 3));
                tempSrc.setPublisher((String) model2.getValueAt(selectedRowIndx[i], 4));
                tempSrc.setCommentOnSrc((String) model2.getValueAt(selectedRowIndx[i], 5));
                tempSrc.setISBN((String) model2.getValueAt(selectedRowIndx[i], 6)); 
                tempSrcList.add(tempSrc);
            }

        this.setVisible(false); //make the current form invisible
        new frmPrintBibliography(tempSrcList, rdoAPA.isSelected(), rdoMLA.isSelected()).setVisible(true); //make this form visible
    }//GEN-LAST:event_btnNextActionPerformed

    private void lbUsernameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbUsernameMouseClicked
        txtUsername.requestFocus(); //Unlike C# which uses "Focus", Java uses "requestFocus()"
    }//GEN-LAST:event_lbUsernameMouseClicked

    private void lbPasswordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbPasswordMouseClicked
        txtPassword.requestFocus();
    }//GEN-LAST:event_lbPasswordMouseClicked

    private void lbConfirmPasswordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbConfirmPasswordMouseClicked
        txtConfirmPassword.requestFocus();
    }//GEN-LAST:event_lbConfirmPasswordMouseClicked

    private void lbEmailMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbEmailMouseClicked
        txtEmail.requestFocus();
    }//GEN-LAST:event_lbEmailMouseClicked

    private void lbAnswerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbAnswerMouseClicked
        txtAnswer.requestFocus();
    }//GEN-LAST:event_lbAnswerMouseClicked

    //gives the security questions combox focus 
    private void lbSecurityQ2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbSecurityQ2MouseClicked
        cboSecurityQ2.requestFocus();
    }//GEN-LAST:event_lbSecurityQ2MouseClicked
    // Either creates a new list based on the user's entry or clear the user's entry, and restore the initial list
    private void lbSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbSearchMouseClicked
        if (!"".equals(txtSearch.getText()) | !"Search for Sources".equals(txtSearch.getText())){
            txtSearch.setText("");
            fillBookSourceJTable2();
            txtSearch.requestFocus();
            }
    }//GEN-LAST:event_lbSearchMouseClicked

        //Note used
    private void txtSearchInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtSearchInputMethodTextChanged

    }//GEN-LAST:event_txtSearchInputMethodTextChanged

    Font ft = null; //Class scope
    //Clear the text in the search field, ready it for user entry
    private void txtSearchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSearchFocusGained
        txtSearch.setText("");
        txtSearch.setForeground(Color.BLACK);
        
        if(ft == null){
        ft = txtSearch.getFont(); //stores the initial font before we change it
        }
        
        txtSearch.setFont(new java.awt.Font(Font.SANS_SERIF, Font.PLAIN, 12));
    }//GEN-LAST:event_txtSearchFocusGained

    //if there are no user entries, and the field loses focus, this method reset the test to...
    private void txtSearchFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSearchFocusLost
        if (txtSearch.getText().length() == 0){
                txtSearch.setFont(ft); //set the font to the font that was store initially
                txtSearch.setForeground(Color.GRAY);
                txtSearch.setText("Search for Sources");
                fillBookSourceJTable2();
                GetBibTable1.requestFocus();
            }
        
    }//GEN-LAST:event_txtSearchFocusLost

    //
    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed

        
        if(evt.getSource().equals(txtSearch)){
            if (!"Search for Sources".equals(txtSearch.getText()) || !"".equals(txtSearch.getText())){
                    try{
                        if (!"".equals(txtSearch.getText()) | !"Search for Sources".equals(txtSearch.getText())){
                              ImageIcon lbImageIcon = new ImageIcon("th2.jpg"); //NOTE THIS. Setting the icon for the application
                            //  Image lbImage = lbImageIcon.getImage();///
                              lbSearch.setIcon(lbImageIcon);///
                        }
                    }
                    catch (Exception problem){
                        JOptionPane.showMessageDialog(null,"Cannot find the image"+ problem.getMessage());
                    }
                    /////////////////////////////////////////////////////////////////

                    try{
                        if ("".equals(txtSearch.getText()) | "Search for Sources".equals(txtSearch.getText())){
                            ImageIcon img = new ImageIcon("th1.jpg");
                          //  Image img2 = img.getImage();
                            lbPreviewPic.setIcon(img);
                        }
                    }
                    catch (Exception problem){
                        JOptionPane.showMessageDialog(null, "Cannot find the image"+ problem.getMessage());
                    }
                    searchSource(txtSearch.getText(), bookSrcs);
                }
        }
    }//GEN-LAST:event_txtSearchActionPerformed
///////////////////////////////////////////////////////////////////////////////
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCreate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCreate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCreate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCreate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmCreate().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable GetBibTable1;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBack1;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnSubmit;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cboSecurityQ2;
    private javax.swing.JPanel jAccPanel;
    private javax.swing.JPanel jBibFormatPanel;
    private javax.swing.JPanel jCreateBibPanel;
    private javax.swing.JPanel jMainPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbAnswer;
    private javax.swing.JLabel lbConfirmPassword;
    private javax.swing.JLabel lbEmail;
    private javax.swing.JLabel lbExit;
    private javax.swing.JLabel lbPassword;
    private javax.swing.JLabel lbPreview;
    private javax.swing.JLabel lbPreviewPic;
    private javax.swing.JLabel lbSearch;
    private javax.swing.JLabel lbSecurityQ2;
    private javax.swing.JLabel lbUsername;
    private javax.swing.JRadioButton rdoAPA;
    private javax.swing.JRadioButton rdoMLA;
    private javax.swing.JTextField txtAnswer;
    private javax.swing.JPasswordField txtConfirmPassword;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}
