import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kelvin B
 */
public class frmRemoveASource extends JFrame {
        //Member variable//
    ArrayList<GetBibSources> UserSrcs2; //class scope
    
    /**
     * Creates new form frmRemoveASource
     */
    public frmRemoveASource() {
        initComponents();
        FillBookSourceListView();
        init();
    }
    
    private void init(){//Internal code that sets up the frame
        // setTitle("Image Demo");
      
    //    setSize(600, 480); //set size of frame
        setLocationRelativeTo(null); //centers the frame
        setVisible(true);
        ImageIcon ImageIcon = new ImageIcon("H:\\MyJavaGUI\\GetBib\\src\\favicon.jpg"); //NOTE THIS. Setting the icon for the application
        Image Image = ImageIcon.getImage();///
        this.setIconImage(Image);///
       
        //setLayout(null); //setup the frame as blank
        //setToFiveButton.addActionListener(null); already taken care off
    }
        static DefaultTableModel model = null;//Class scope
        /// <summary>
        /// This method fills the list view with the user-defined book sources
        /// </summary>
        private void FillBookSourceListView(){
         
            ArrayList<GetBibSources> UserSrcs = GetBibMemberClassDB.GetUserSources(GetBibValidation.returnUserTableID()); // store all the sources for now. //Might have to make this static
            UserSrcs2 = UserSrcs; //GetBibMemberClassDB.GetUserSources(GetBibValidation.returnUserTableID());
            model = (DefaultTableModel)GetBibTable2.getModel();

            for(int src = 0; src < UserSrcs2.size(); src++){
                model.addRow(new Object[]{UserSrcs2.get(src).Authors(), UserSrcs2.get(src).returnSourceTitle(), UserSrcs2.get(src).Date(), UserSrcs2.get(src).returnPlaceOfPub(), UserSrcs2.get(src).returnPublisher(), UserSrcs2.get(src).returnCommentOnSrc(), UserSrcs2.get(src).returnISBN()}); //
                
            }
            UserSrcs.clear(); //"clear()" instead of Clear() in C#
        }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        removeASourcePanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        RemoveaSourcePanel2 = new javax.swing.JPanel();
        btnDelete = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        GetBibTable2 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 128, 0));
        setName("frmRemoveASource"); // NOI18N
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(796, 394));

        removeASourcePanel1.setBackground(new java.awt.Color(255, 128, 0));
        removeASourcePanel1.setPreferredSize(new java.awt.Dimension(796, 366));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon_LiveForensics.jpg"))); // NOI18N
        jLabel1.setToolTipText("closes application");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.setName("lbExit"); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        RemoveaSourcePanel2.setBackground(new java.awt.Color(255, 128, 0));
        RemoveaSourcePanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Remove A Source", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Microsoft Sans Serif", 1, 12), new java.awt.Color(0, 0, 0))); // NOI18N
        RemoveaSourcePanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 12)); // NOI18N
        RemoveaSourcePanel2.setPreferredSize(new java.awt.Dimension(788, 328));

        btnDelete.setBackground(new java.awt.Color(255, 128, 0));
        btnDelete.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12)); // NOI18N
        btnDelete.setText("Delete");
        btnDelete.setToolTipText("delete the selected form");
        btnDelete.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 128, 0)));
        btnDelete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnDelete.setPreferredSize(new java.awt.Dimension(75, 23));
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnBack.setBackground(new java.awt.Color(255, 128, 0));
        btnBack.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12)); // NOI18N
        btnBack.setText("Back");
        btnBack.setToolTipText("return to add source form?");
        btnBack.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 128, 0)));
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.setPreferredSize(new java.awt.Dimension(75, 23));
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        GetBibTable2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12)); // NOI18N
        GetBibTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Author", "Source Title", "Date of Publication", "Place of Publication", "Publisher", "Comment", "ISBN"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        GetBibTable2.setGridColor(new java.awt.Color(255, 255, 255));
        GetBibTable2.setName("GetBibTable2"); // NOI18N
        GetBibTable2.setSelectionBackground(new java.awt.Color(102, 0, 102));
        GetBibTable2.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(GetBibTable2);

        javax.swing.GroupLayout RemoveaSourcePanel2Layout = new javax.swing.GroupLayout(RemoveaSourcePanel2);
        RemoveaSourcePanel2.setLayout(RemoveaSourcePanel2Layout);
        RemoveaSourcePanel2Layout.setHorizontalGroup(
            RemoveaSourcePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 784, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RemoveaSourcePanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        RemoveaSourcePanel2Layout.setVerticalGroup(
            RemoveaSourcePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RemoveaSourcePanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 287, Short.MAX_VALUE)
                .addGap(84, 84, 84)
                .addGroup(RemoveaSourcePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout removeASourcePanel1Layout = new javax.swing.GroupLayout(removeASourcePanel1);
        removeASourcePanel1.setLayout(removeASourcePanel1Layout);
        removeASourcePanel1Layout.setHorizontalGroup(
            removeASourcePanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(removeASourcePanel1Layout.createSequentialGroup()
                .addContainerGap(764, Short.MAX_VALUE)
                .addComponent(jLabel1))
            .addComponent(RemoveaSourcePanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 796, Short.MAX_VALUE)
        );
        removeASourcePanel1Layout.setVerticalGroup(
            removeASourcePanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(removeASourcePanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RemoveaSourcePanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 418, Short.MAX_VALUE))
        );

        RemoveaSourcePanel2.getAccessibleContext().setAccessibleName("removeASource");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(removeASourcePanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(removeASourcePanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 456, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //This is the event handler for the close button.
    //It closes the application when clicked
    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
//Create mouseClicked event for JTable to get data from selected row to input form fields
        //JOptionPane.showMessageDialog(null, "Number of rows: "+GetBibTable2.getRowCount() + "\nNumber of selected rows: " + GetBibTable2.getSelectedRow());
        
        model = (DefaultTableModel)GetBibTable2.getModel(); //method scope
        try{
            if(model.getRowCount() == 0){ //the table is empty//   GetBibTable2.getSelectedRow() == -1 && 
                JOptionPane.showMessageDialog(null, "There are no sources created for this end-user");
            }

            if(GetBibTable2.getSelectedRowCount() == 0 && GetBibTable2.getRowCount() > 0){ // the user did not make any selection
                
                if(JOptionPane.showConfirmDialog(this,"Delete everything?","Note",JOptionPane.YES_NO_CANCEL_OPTION) == 0){
                    
                    for(int items = 0; items < model.getRowCount(); items++){ //DOES NOT DELETE EVERYTHING
                        //remove the row from the table                            //    r   X  c
                        if(GetBibMemberClassDB.deleteUserSource(GetBibValidation.returnUserTableID(), (String) model.getValueAt(items, 1)) == true){ //delete from the database
                            model.removeRow(items); //index
                            
                            GetBibTable2.revalidate();
                           
                        }
                        
                        else{
                            break; //break out of the loop
                        }
                    }
                    
//                    int x = 0;
//                    while(x < model.getRowCount()){
                        
                  //  }
                    JOptionPane.showMessageDialog(null,"Deletion was successful");
                }   
            }
            
            if(GetBibTable2.getSelectedRow() > -1 && GetBibTable2.getSelectedRowCount() > 0){ //The user selected something
                //If JTable is not empty, and end-user selects a product, perform deleting the selected row, use "removeRow(int row)"
                //method object to remove selected row
                GetBibMemberClassDB.deleteUserSource(GetBibValidation.returnUserTableID(), (String)model.getValueAt(GetBibTable2.getSelectedRow(), 1)); 
                model.removeRow(GetBibTable2.getSelectedRow()); //remove from the table
                JOptionPane.showMessageDialog(null,"Deletion was successful");
            }
            
            //int[] selectindices = GetBibTable2.getSelectedRows();
            //((Vector)getDataVector().elementAt(1)).elementAt(5);
            //JTable.CheckedListViewItemCollection checkedItems = GetBibTable2.CheckedItems; //a collection of checked items
           
            }
            catch (Exception p){
                JOptionPane.showMessageDialog(null, "Please make a selection first \n" + p.getMessage() + "\n\n" + p.getStackTrace());
            }

            finally{
           //     btnRefresh.requestFocus(); //give the focus to the refresh button. thereby the user wont need to use the mouse, but rather the enter button
            }
    }//GEN-LAST:event_btnDeleteActionPerformed

    //Displays the AddaSource form//
    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false); //make the current form invisible
        new frmAddaSource().setVisible(true); //make this form visible
    }//GEN-LAST:event_btnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmRemoveASource.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmRemoveASource.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmRemoveASource.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmRemoveASource.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmRemoveASource().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable GetBibTable2;
    private javax.swing.JPanel RemoveaSourcePanel2;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnDelete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel removeASourcePanel1;
    // End of variables declaration//GEN-END:variables
}
