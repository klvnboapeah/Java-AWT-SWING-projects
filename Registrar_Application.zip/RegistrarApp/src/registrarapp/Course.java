/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package registrarapp;

import java.sql.Timestamp;
import java.util.Date;

/**
 *This is the class of the course object
 * @author Kelvin
 * @see http://www.kelv-b.com
 */
public class Course {
    private int courseIdentificationNumber;
    private String courseName;
    private String courseDayNTime;
    private String courseInstructor;
    private String courseCreationDate;
    private String courseComment;
    
    /**
     * Course object's no-argument constructor
     */
    public Course(){this.courseCreationDate = String.valueOf(new Timestamp(new Date().getTime()));}
    
    /**
     * Course object's constructor
     * @param courseIdentificationNumber the course identification number
     * @param courseName the course name
     * @param courseDayNTime the day and time the course is offered
     * @param courseInstructor the instructor who teaches this course
     * @param courseCreationDate the day the course was created
     * @param courseComment the comment / note / description about the course
     */
    public Course(int courseIdentificationNumber, String courseName, String courseDayNTime, String courseInstructor, String courseComment)
    {
        this.courseIdentificationNumber = courseIdentificationNumber;
        this.courseName = courseName;
        this.courseDayNTime = courseDayNTime;
        this.courseInstructor = courseInstructor;
        this.courseCreationDate = String.valueOf(new Timestamp(new Date().getTime()));
        this.courseComment = courseComment;
    }
    
      public Course(int courseIdentificationNumber, String courseName, String courseDayNTime, String courseInstructor, String coursedd ,String courseComment)
    {
        this.courseIdentificationNumber = courseIdentificationNumber;
        this.courseName = courseName;
        this.courseDayNTime = courseDayNTime;
        this.courseInstructor = courseInstructor;
        this.courseCreationDate = coursedd;
        this.courseComment = courseComment;
    }
    
    
    
    //mutators///////////////////////////////////////////////////////////////////
    /**
     * Sets the course number
     * @param cID the course identification number (Integer)
     */
    public void setCourseID(int cID){this.courseIdentificationNumber = cID;}
    
    /**
     * Sets the course name
     * @param strCourseName the course name (String)
     */
    public void setCourseName(String strCourseName){this.courseName = strCourseName;}
    
    /**
     * Sets the day and time the course is offered
     * @param strCourseDayNTime the day and time (String)
     */
    public void setCourseDayNTime(String strCourseDayNTime){this.courseDayNTime = strCourseDayNTime;}
    
    /**
     * Sets the instructor who teaches the course
     * @param strInstructorName the name of the instructor who teaches this course
     */
    public void setCourseInstructor(String strInstructorName){this.courseInstructor = strInstructorName;}
    
    /**
     * Sets the date the course was created
     * @param strCourseCreationDate String 
     */
    public void setCourseCreationDate(String strCourseCreationDate){this.courseCreationDate = strCourseCreationDate;}
    
    /**
     * Sets the course description 
     * @param strCourseDescription String
     */
    public void setDescription(String strCourseDescription){this.courseComment = strCourseDescription;}
    
    //Accessors////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Gets the course identification number
     * @return An Integer
     */
    public int getCourseID(){return this.courseIdentificationNumber;}
    
    /**
     * Gets the course name
     * @return A String
     */
    public String getCourseName(){return this.courseName;}
    
    /**
     * Gets the day and time the course is offered
     * @return A String
     */
    public String getCourseDayNTime(){return this.courseDayNTime;}
    
    /**
     * Gets the full name of the instructor who teaches this course
     * @return A String
     */
    public String getCourseInstructor(){return this.courseInstructor;}
    
    /**
     * Gets the date the course was created
     * @return A String
     */
    public String getCourseCreationDate(){return this.courseCreationDate;}
    
    /**
     * Gets the description of the course
     * @return A String
     */
    public String getCourseDescription(){return this.courseComment;}
}

