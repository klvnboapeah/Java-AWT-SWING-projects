/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
JOptionPane.showMessageDialog(null, "Note: " + JTblAllCourses.getValueAt(JTblAllCourses.getSelectedRow(), 0) +
                        "\n" + JTblAllCourses.getValueAt(JTblAllCourses.getSelectedRow(), 1) + "\n" +
                        JTblAllCourses.getValueAt(JTblAllCourses.getSelectedRow(), 2) + "\n" + JTblAllCourses.getValueAt(JTblAllCourses.getSelectedRow(), 3) +
                        "\n" + JTblAllCourses.getValueAt(JTblAllCourses.getSelectedRow(), 4) + "\n" + JTblAllCourses.getValueAt(JTblAllCourses.getSelectedRow(), 5));
 */

package registrarapp;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static registrarapp.ControlsInterface.stu;

/**
 * This form displays information about a given course
 * @author Kelvin B
 * @see http://www.kelv-b.com
 */
public class CourseInformation extends JFrame {
//Member variables///
    private static int frmID = -1;
    private static String frmTitle = "";
    
    /**
     * Creates new form CourseInformation
     */
    public CourseInformation() {
        initComponents();
        this.setLocationRelativeTo(null); //centers the form
        /////////////////////////////
    }
    
    /**
     * This method does some initialization
     * @param linklis A Course
     */
    protected void CrsInfo(Course linklis){
        frmTitle = linklis.getCourseName();
        this.setTitle(frmTitle);
        JLblCourseID2.setText(String.valueOf(linklis.getCourseID()));
        JLblCourseName2.setText(frmTitle); //sets the course name in the form
        JLblCourseDayTime2.setText(linklis.getCourseDayNTime());
        JLblCourseInstructor2.setText(linklis.getCourseInstructor());
        JLblCourseCreationDate2.setText(linklis.getCourseCreationDate());
        JtxtAreaCourseDesc.setText(linklis.getCourseDescription());
        initialCourseRosterRetriever(String.valueOf(linklis.getCourseID()), linklis.getCourseName());//populate the course roster table
    }
    
    /**
     * The method populates the course table /roster
     * @param c1 course identification number
     * @param  c2 course name
     */
     private void initialCourseRosterRetriever(String c1, String c2){
        //resets the table model, cast it to "defaulttablemodel" and assign it to "model"
        DefaultTableModel modelRoster;
        String tempTableName = "";
        modelRoster = (DefaultTableModel)resetTblCourseRosterModel(JTblCourseRoster.getModel());
        ///////////////////////////////////////////////////////////////
        try{
            //////////////////Creating student schedule table name/////////////////////////////
                String strCrsRosterName = c2 + c1+"Roster";
        ////////validating table name////////////////////////////////////////////////
                tempTableName = strCrsRosterName.replace(" ", "");
                tempTableName = tempTableName.replace("'", "");
                tempTableName = tempTableName.replace(",", "");
                tempTableName = tempTableName.replace("?", "");//remove ?
                tempTableName = tempTableName.replace(">", "");
                tempTableName = tempTableName.replace("<", "");
                tempTableName = tempTableName.replace("[", "");
                tempTableName = tempTableName.replace("]", "");
                tempTableName = tempTableName.replace("(", "");
                tempTableName = tempTableName.replace(")", "");
                tempTableName = tempTableName.replace("/", "");
                tempTableName = tempTableName.replace("\\", "");
                tempTableName = tempTableName.replace("-", "");
                tempTableName = tempTableName.replace("_", "");
                tempTableName = tempTableName.replace("%", "");
                tempTableName = tempTableName.replace("^", "");
                tempTableName = tempTableName.replace("&", "");
                tempTableName = tempTableName.replace("*", "");
                tempTableName = tempTableName.replace("#", "");
                tempTableName = tempTableName.replace("@", "");
                tempTableName = tempTableName.replace("!", "");
                tempTableName = tempTableName.replace("~", "");
                tempTableName = tempTableName.replace("`", "");
                tempTableName = tempTableName.replace("\"", "");
                tempTableName = tempTableName.replace("+", "");
                tempTableName = tempTableName.replace("=", "");
                tempTableName = tempTableName.replace("|", "");
                /////////////////////////
            Connection c = SqliteDBConnector.ConnectionDb();
            Statement st = c.createStatement();
            String query="SELECT * FROM " + tempTableName +";";
            ResultSet rs = st.executeQuery(query);

            while(rs.next())
            {                            
                //
                modelRoster.addRow(new Object[]{rs.getString("studentid"), rs.getString("studentfirstN"), 
                    rs.getString("studentmiddleN"), rs.getString("studentlastN"),
                    rs.getString("studentdateofadmin"), rs.getString("stucomment")}); //Added the course to the course table
                ///////////////////////////
            }
            rs.close();
            st.close();
            c.close();
        }
        catch(NumberFormatException | SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
     
      /**
     * The method resets the model for the respective table
     * @param mod The model to be reset
     * @return TableModel The model reseted
     */
    private TableModel resetTblCourseRosterModel(TableModel mod){
        for(int eraser = (mod.getRowCount() - 1); eraser > -1; eraser--){//-1 accounts for the o index
            ((DefaultTableModel)mod).removeRow(eraser);//removes each row in the model for the next use
        }
        return mod;
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JCoursePanel = new javax.swing.JPanel();
        JCoursePanelSpliter = new javax.swing.JSeparator();
        JLblCourseID = new javax.swing.JLabel();
        JLblCourseName = new javax.swing.JLabel();
        JLblCourseDayTime = new javax.swing.JLabel();
        JLblCourseInstructor = new javax.swing.JLabel();
        JCourseCreaDate = new javax.swing.JLabel();
        JLblCourseName2 = new javax.swing.JLabel();
        JLblCourseDayTime2 = new javax.swing.JLabel();
        JLblCourseID2 = new javax.swing.JLabel();
        JLblCourseInstructor2 = new javax.swing.JLabel();
        JLblCourseCreationDate2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTblCourseRoster = new javax.swing.JTable();
        JLblCourseRoster = new javax.swing.JLabel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 32), new java.awt.Dimension(0, 32), new java.awt.Dimension(32767, 32));
        JLblCourseNote = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        JtxtAreaCourseDesc = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(0, 51, 204));
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setName("frmCourseInfor"); // NOI18N
        setPreferredSize(new java.awt.Dimension(1200, 700));

        JCoursePanel.setBackground(new java.awt.Color(255, 255, 255));
        JCoursePanel.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(255, 102, 0), null));
        JCoursePanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        JCoursePanelSpliter.setBackground(new java.awt.Color(255, 153, 0));
        JCoursePanelSpliter.setForeground(new java.awt.Color(99, 103, 255));

        JLblCourseID.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        JLblCourseID.setText("Course Identification Number:");

        JLblCourseName.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        JLblCourseName.setText("Course Name:");

        JLblCourseDayTime.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        JLblCourseDayTime.setText("Day and Time:");

        JLblCourseInstructor.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        JLblCourseInstructor.setText("Course Instructor:");

        JCourseCreaDate.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        JCourseCreaDate.setText("Course Creation Date:");

        JLblCourseName2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        JLblCourseName2.setText("N/A");

        JLblCourseDayTime2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        JLblCourseDayTime2.setText("N/A");

        JLblCourseID2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        JLblCourseID2.setText("N/A");

        JLblCourseInstructor2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        JLblCourseInstructor2.setText("N/A");
        JLblCourseInstructor2.setToolTipText("");

        JLblCourseCreationDate2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        JLblCourseCreationDate2.setText("N/A");

        JTblCourseRoster.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Identification Number", "First Name", "Middle Name", "Last Name", "Date of Admittance", "Student Comment"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(JTblCourseRoster);

        JLblCourseRoster.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        JLblCourseRoster.setText("Course Roster");

        JLblCourseNote.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        JLblCourseNote.setText("Course Note:");

        JtxtAreaCourseDesc.setEditable(false);
        JtxtAreaCourseDesc.setColumns(20);
        JtxtAreaCourseDesc.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        JtxtAreaCourseDesc.setRows(5);
        JtxtAreaCourseDesc.setWrapStyleWord(true);
        jScrollPane2.setViewportView(JtxtAreaCourseDesc);

        javax.swing.GroupLayout JCoursePanelLayout = new javax.swing.GroupLayout(JCoursePanel);
        JCoursePanel.setLayout(JCoursePanelLayout);
        JCoursePanelLayout.setHorizontalGroup(
            JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JCoursePanelSpliter, javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(jScrollPane1)
            .addGroup(JCoursePanelLayout.createSequentialGroup()
                .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JCoursePanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(JLblCourseRoster, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(JCoursePanelLayout.createSequentialGroup()
                        .addGap(559, 559, 559)
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(JCoursePanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(JCourseCreaDate)
                    .addComponent(JLblCourseInstructor, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLblCourseDayTime)
                    .addComponent(JLblCourseID, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLblCourseName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JLblCourseCreationDate2, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLblCourseDayTime2, javax.swing.GroupLayout.PREFERRED_SIZE, 440, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLblCourseInstructor2, javax.swing.GroupLayout.PREFERRED_SIZE, 449, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLblCourseName2, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(JCoursePanelLayout.createSequentialGroup()
                        .addComponent(JLblCourseID2, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(JLblCourseNote)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 399, Short.MAX_VALUE))
        );
        JCoursePanelLayout.setVerticalGroup(
            JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JCoursePanelLayout.createSequentialGroup()
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JCoursePanelLayout.createSequentialGroup()
                        .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JLblCourseID, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(JLblCourseID2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(JLblCourseNote))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JLblCourseName, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JLblCourseName2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JLblCourseInstructor, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JLblCourseInstructor2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JLblCourseDayTime, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JLblCourseDayTime2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(JCoursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JCourseCreaDate, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JLblCourseCreationDate2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JCoursePanelSpliter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(JLblCourseRoster)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JCoursePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(JCoursePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleName("CourseInfofrm");
        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CourseInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CourseInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CourseInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CourseInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CourseInformation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JCourseCreaDate;
    private javax.swing.JPanel JCoursePanel;
    private javax.swing.JSeparator JCoursePanelSpliter;
    private javax.swing.JLabel JLblCourseCreationDate2;
    private javax.swing.JLabel JLblCourseDayTime;
    private javax.swing.JLabel JLblCourseDayTime2;
    private javax.swing.JLabel JLblCourseID;
    private javax.swing.JLabel JLblCourseID2;
    private javax.swing.JLabel JLblCourseInstructor;
    private javax.swing.JLabel JLblCourseInstructor2;
    private javax.swing.JLabel JLblCourseName;
    private javax.swing.JLabel JLblCourseName2;
    private javax.swing.JLabel JLblCourseNote;
    private javax.swing.JLabel JLblCourseRoster;
    private javax.swing.JTable JTblCourseRoster;
    private javax.swing.JTextArea JtxtAreaCourseDesc;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
