/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package registrarapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Kelvin
 */
public class DBConnection {
    Connection conn = null;
    
    
    public static Connection ConnecrDb(){
        try{
            Class.forName("org.sqlite.JDBC");//com.mysql.jdbc.Driver | jdbc:mysql://localhost/...., username, password
            Connection conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Kelvin\\Documents\\NetBeansProjects\\RegistrarApp\\rappDB.sqlite");
            JOptionPane.showMessageDialog(null, "Connection established!");
            return conn;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
}
