/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package registrarapp;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static registrarapp.ControlsInterface.crs;
import static registrarapp.ControlsInterface.stu;
import static registrarapp.GenericEntityCreator.InsertCourseIntoSchedule;
import static registrarapp.GenericEntityCreator.InsertStudentIntoRoster;

/**
 * This form allows the user to add a course to a students schedule, and to 
 * add a student to a course roster.
 * @author Kelvin B
 * @see http://www.kelv-b.com
 */
public class FrmScheduleRosterCreator extends JFrame {
//Member variables///
    private ArrayList<Course> crsList;
    private ArrayList<Student> stuList;
    
    /**
     * Creates new form FrmScheduleRosterCreator
     * @param tf "true" if we want the course table data filtered, and "false" if we all the courses in the course table
     */
    public FrmScheduleRosterCreator(boolean tf){
        initComponents();
        this.setLocationRelativeTo(null);//Centers the form
        this.setTitle("Create Schedule | Roster");
        ////////////////////////////////////////////////////////////////////////
        //////////////Setting the textchanged listener for searchboxstudent///////////////////////////////////////////
        JtxtSearchBoxStudent.getDocument().addDocumentListener(new DocumentListener() {
            /**
             * This method does some processing when a character is removed from the entry field
             * @param e Not Used
             */
            @Override
            public void removeUpdate(DocumentEvent e) {
                if(JtxtSearchBoxStudent.getText().length() == 0){
                    retrieveCourseScheduleInfo(1); //Refresh the table to view the data saved
                }
            }
            /**
             * Not Used
             * @param e Not Used
             */
            @Override
            public void insertUpdate(DocumentEvent e){}
            /**
             * This method is Not Used
             * @param arg0 Not Used
             */
            @Override
            public void changedUpdate(DocumentEvent arg0) {}
        }); 
      //////////////Setting the textchanged listener for searchboxcourse///////////////////////////////////////////
        JtxtSearchBoxCourses.getDocument().addDocumentListener(new DocumentListener() {
            /**
             * This method does some processing when a character is removed from the entry field
             * @param e Not Used
             */
            @Override
            public void removeUpdate(DocumentEvent e) {
                if(JtxtSearchBoxCourses.getText().length() == 0){
                    retrieveCourseScheduleInfo(2); //Refresh the table to view the data saved
                }
            }
            /**
             * Not Used
             * @param e Not Used
             */
            @Override
            public void insertUpdate(DocumentEvent e){}
            /**
             * This method is Not Used
             * @param arg0 Not Used
             */
            @Override
            public void changedUpdate(DocumentEvent arg0) {}
        });     
        
        //MORE CODE////
        if(tf == false)
            retrieveCourseScheduleInfo(3); //populate the table
    }
    
      /**
     * This method creates a list of selected students
     * @param tblStu A reference to the view all students table
     * @param linkhead A reference to the students linked list
     * **/
    public void returnUserSelectedRows2(JTable tblStu, SCNode linkhead){
        stuList = stu.searchListForS(linkhead, tblStu, tblStu.getSelectedRows());//Retrieve the selected rows
        frmScheduleRosterCreator2(true); //Populate the students table with the user's selected rows | And the courses row with all the courses
    }
    
        /**
     * This method creates a list of selected courses
     * @param tblCrs A reference to the view all courses table
     * @param linkhead A reference to the course linked-list
     * **/
    public void returnUserSelectedRows(JTable tblCrs, SCNode linkhead){
        crsList = crs.searchListForC(linkhead, tblCrs, tblCrs.getSelectedRows());//Retrieve the selected rows
        frmScheduleRosterCreator(true); //Populate the courses table with the user's selected rows | And the students row with all the students
    }
    
    
    /**
     * This method populated the courses table with filtered courses, and the student table with all the students
     * @param TF true, if the user accessed this form through the view all courses page,
     * and selected a course
     */
    private void frmScheduleRosterCreator(boolean TF) {
        DefaultTableModel modelStu, modelCourse;
        modelCourse = (DefaultTableModel)resetTblModel(JTblCourses.getModel());
        modelStu = (DefaultTableModel)resetTblModel(JTblStudents.getModel());
        //MORE CODE////
        if(TF == true && crsList != null){
            //////////////////////////////////Adding students to the student table///////////////////////////////////////////////////////////////
            for(SCNode x = stu.getHeadReference(1).getNext(); x.getNext() != null; x = x.getNext())
            {
                modelStu.addRow(new Object[]{String.valueOf(((Student)x.getData()).getStudentID()),
                ((Student)x.getData()).getStudentFirstName(), ((Student)x.getData()).getStudentMiddleName(),
                ((Student)x.getData()).getStudentLastName(),((Student)x.getData()).getStudentDateOfAdmittance(),
                ((Student)x.getData()).getStudentComment()}); //Added the students to the student table
            }
            
            for (Course crsList1 : crsList) {
                modelCourse.addRow(new Object[]{String.valueOf(crsList1.getCourseID()), 
                    crsList1.getCourseName(), crsList1.getCourseDayNTime(), crsList1.getCourseInstructor(), 
                    crsList1.getCourseCreationDate(), crsList1.getCourseDescription()}); 
                    //Added the filtered courses to the course table
            }
        }   
    }
    
    /**
     * This method populated the courses table with filtered courses, and the student table with all the students
     * @param TF true, if the user accessed this form through the view all courses page,
     * and selected a course
     */
    private void frmScheduleRosterCreator2(boolean TF) {
        DefaultTableModel modelStu, modelCourse;
        modelCourse = (DefaultTableModel)resetTblModel(JTblCourses.getModel());
        modelStu = (DefaultTableModel)resetTblModel(JTblStudents.getModel());
        //MORE CODE////
        if(TF == true && crsList == null){
            //////////////////////////////////Adding students to the student table///////////////////////////////////////////////////////////////
            for(SCNode x = crs.getHeadReference(2).getNext(); x.getNext() != null; x = x.getNext())
            {
                modelCourse.addRow(new Object[]{String.valueOf(((Course)x.getData()).getCourseID()),
                ((Course)x.getData()).getCourseName(), ((Course)x.getData()).getCourseDayNTime(),
                ((Course)x.getData()).getCourseInstructor(),((Course)x.getData()).getCourseCreationDate(),
                ((Course)x.getData()).getCourseDescription()}); //Added the students to the student table
            }
            
            for (Student stulist : stuList) {
                modelStu.addRow(new Object[]{String.valueOf(stulist.getStudentID()), 
                    stulist.getStudentFirstName(), stulist.getStudentMiddleName(), stulist.getStudentLastName(), 
                    stulist.getStudentDateOfAdmittance(), stulist.getStudentComment()}); 
                    //Added the filtered student to the student table
            }
        }   
    }
    
    /**
     * This method populates the student and course tables
     */
    private void retrieveCourseScheduleInfo(int i){
        DefaultTableModel modelStu, modelCourse;
//////////////////////////////Adding courses to the course table//////////////////////////////////////////////////////////////////
        if(i == 2){
            modelCourse = (DefaultTableModel)resetTblModel(JTblCourses.getModel());
            /////////////////////////////////////////////////////////////////////
            for(SCNode x = crs.getHeadReference(2).getNext(); x.getNext() != null; x = x.getNext())
            {
                modelCourse.addRow(new Object[]{String.valueOf(((Course)x.getData()).getCourseID()), 
                    ((Course)x.getData()).getCourseName(), ((Course)x.getData()).getCourseDayNTime(),
                        ((Course)x.getData()).getCourseInstructor(),((Course)x.getData()).getCourseCreationDate(),
                        ((Course)x.getData()).getCourseDescription()}); //Added the course to the course table
            }
        }
        //////////////////////////////////Adding students to the student table///////////////////////////////////////////////////////////////
        if(i == 1) {
            modelStu = (DefaultTableModel)resetTblModel(JTblStudents.getModel());
            ////////////////////////////////////////////////////////////////////////////////////////////
            for(SCNode x = stu.getHeadReference(1).getNext(); x.getNext() != null; x = x.getNext())
            {
                modelStu.addRow(new Object[]{String.valueOf(((Student)x.getData()).getStudentID()),
                    ((Student)x.getData()).getStudentFirstName(), ((Student)x.getData()).getStudentMiddleName(),
                    ((Student)x.getData()).getStudentLastName(),((Student)x.getData()).getStudentDateOfAdmittance(),
                    ((Student)x.getData()).getStudentComment()}); //Added the student to the student table
            }
        }
        ///////////////////////Adding courses to course table | Adding students to the student table////////////
        if(i == 3){
            modelCourse = (DefaultTableModel)resetTblModel(JTblCourses.getModel());
            modelStu = (DefaultTableModel)resetTblModel(JTblStudents.getModel());
            ///////////////////////////////////////////////////////////////////////
            for(SCNode x = crs.getHeadReference(2).getNext(); x.getNext() != null; x = x.getNext())
            {
                modelCourse.addRow(new Object[]{String.valueOf(((Course)x.getData()).getCourseID()), 
                    ((Course)x.getData()).getCourseName(), ((Course)x.getData()).getCourseDayNTime(),
                        ((Course)x.getData()).getCourseInstructor(),((Course)x.getData()).getCourseCreationDate(),
                        ((Course)x.getData()).getCourseDescription()}); //Added the course to the course table
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////////
            for(SCNode x = stu.getHeadReference(1).getNext(); x.getNext() != null; x = x.getNext())
            {
                modelStu.addRow(new Object[]{String.valueOf(((Student)x.getData()).getStudentID()),
                    ((Student)x.getData()).getStudentFirstName(), ((Student)x.getData()).getStudentMiddleName(),
                    ((Student)x.getData()).getStudentLastName(),((Student)x.getData()).getStudentDateOfAdmittance(),
                    ((Student)x.getData()).getStudentComment()}); //Added the student to the student table
            }
        }
    }
    
        /**
     * The method resets the model for the respective table
     * @param mod The model to be reset
     * @return TableModel The model reseted
     */
    private TableModel resetTblModel(TableModel mod){
        for(int eraser = (mod.getRowCount() - 1); eraser > -1; eraser--){//-1 accounts for the o index
            ((DefaultTableModel)mod).removeRow(eraser);//removes each row in the model for the next use
        }
        return mod;
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JPanelScheduleRosterCreator = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTblStudents = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        JTblCourses = new javax.swing.JTable();
        JSchRosSplitter = new javax.swing.JSeparator();
        JAllStudents = new javax.swing.JLabel();
        JAllCourses = new javax.swing.JLabel();
        JtxtSearchBoxStudent = new javax.swing.JTextField();
        JtxtSearchBoxCourses = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        JMenuBarSchRos = new javax.swing.JMenuBar();
        JMenuHelp = new javax.swing.JMenu();
        JMenuAbout = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setName("FrmScheduleRosterCreator"); // NOI18N

        JPanelScheduleRosterCreator.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.orange, java.awt.Color.blue));

        JTblStudents.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Identification", "First Name", "Middle Name", "Last Name", "Student Date of Admittance", "Student Comment"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        JTblStudents.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JTblStudents.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JTblStudentsKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(JTblStudents);

        JTblCourses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Course Identification Number", "Course Name", "Day and Time", "Instructor", "Course Creation Date", "Comment"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        JTblCourses.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JTblCourses.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JTblCoursesKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(JTblCourses);

        JAllStudents.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        JAllStudents.setText("All Students");

        JAllCourses.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        JAllCourses.setText("All Courses");

        JtxtSearchBoxStudent.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        JtxtSearchBoxStudent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JtxtSearchBoxStudentActionPerformed(evt);
            }
        });

        JtxtSearchBoxCourses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JtxtSearchBoxCoursesActionPerformed(evt);
            }
        });

        jButton1.setText("search for student");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("search for course");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JPanelScheduleRosterCreatorLayout = new javax.swing.GroupLayout(JPanelScheduleRosterCreator);
        JPanelScheduleRosterCreator.setLayout(JPanelScheduleRosterCreatorLayout);
        JPanelScheduleRosterCreatorLayout.setHorizontalGroup(
            JPanelScheduleRosterCreatorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPanelScheduleRosterCreatorLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(JPanelScheduleRosterCreatorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 579, Short.MAX_VALUE)
                    .addGroup(JPanelScheduleRosterCreatorLayout.createSequentialGroup()
                        .addComponent(JAllStudents)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(JtxtSearchBoxStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(JSchRosSplitter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JPanelScheduleRosterCreatorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(JPanelScheduleRosterCreatorLayout.createSequentialGroup()
                        .addComponent(JAllCourses)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(JtxtSearchBoxCourses, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)))
                .addContainerGap())
        );
        JPanelScheduleRosterCreatorLayout.setVerticalGroup(
            JPanelScheduleRosterCreatorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JSchRosSplitter)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPanelScheduleRosterCreatorLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(JPanelScheduleRosterCreatorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPanelScheduleRosterCreatorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JAllStudents)
                        .addComponent(JtxtSearchBoxStudent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPanelScheduleRosterCreatorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JAllCourses)
                        .addComponent(JtxtSearchBoxCourses, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JPanelScheduleRosterCreatorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        JMenuHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.orange, new java.awt.Color(0, 0, 204)));
        JMenuHelp.setText("Help");
        JMenuHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JMenuBarSchRos.add(JMenuHelp);

        JMenuAbout.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.orange, java.awt.Color.blue));
        JMenuAbout.setText("About");
        JMenuAbout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JMenuBarSchRos.add(JMenuAbout);

        setJMenuBar(JMenuBarSchRos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JPanelScheduleRosterCreator, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JPanelScheduleRosterCreator, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * This method filters the student table, based on the user entry
     * @param evt Not used
     */
    private void JtxtSearchBoxStudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JtxtSearchBoxStudentActionPerformed
        filterStudentsCoursesTable(1);
    }//GEN-LAST:event_JtxtSearchBoxStudentActionPerformed

    /**
     * This method filters the students table, based on user's entry
     * @param evt Not Used Not Used
     */
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        filterStudentsCoursesTable(1);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * This method filters the courses table, based on user's entry
     * @param evt Not Used
     */
    private void JtxtSearchBoxCoursesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JtxtSearchBoxCoursesActionPerformed
        filterStudentsCoursesTable(2);
    }//GEN-LAST:event_JtxtSearchBoxCoursesActionPerformed

    /**
     * This method filters the courses table, based on user's entry
     * @param evt Not Used
     */
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        filterStudentsCoursesTable(2);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * This method interfaces with the method that inserts a student into a roster, and a course 
     * into a schedule
     * @param evt Not Used
     */
    private void JTblStudentsKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTblStudentsKeyPressed
        int userChoice = -1;
        if(JTblStudents.getSelectedRowCount() == 0){
            JOptionPane.showMessageDialog(null, "please select a student");
        }
        else{
            userChoice = JOptionPane.showConfirmDialog(null, "add student to course roster \n and add course to student schedule?","Schedule | Roster",JOptionPane.YES_NO_OPTION);
            if(userChoice == JOptionPane.YES_OPTION)
                insertStuCrs();
        }
    }//GEN-LAST:event_JTblStudentsKeyPressed

    /**
     * This method interfaces with the method that inserts a student into a roster, and a course 
     * into a schedule
     * @param evt Not Used
     */
    private void JTblCoursesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTblCoursesKeyPressed
        int userChoice = -1;
        if(JTblCourses.getSelectedRowCount() == 0){
            JOptionPane.showMessageDialog(null, "Please select a course");
        }
        else{
            userChoice = JOptionPane.showConfirmDialog(null,"add student to course roster \n and add course to student schedule?","Schedule | Roster", JOptionPane.YES_NO_OPTION);
            
            if(userChoice == JOptionPane.YES_OPTION)
                insertStuCrs();
        }  
    }//GEN-LAST:event_JTblCoursesKeyPressed

    /**
     * This method activates the process of inserting a course into a student schedule,
     * and inserting a student into a course roster
     */
    private void insertStuCrs(){
        int [] studentIndicesArray;
        int [] coursesIndicesArray;
        studentIndicesArray = JTblStudents.getSelectedRows();
        coursesIndicesArray = JTblCourses.getSelectedRows();
        String tempCrsTableName, strid, strfn, strmn,strln, strdoa, strdesc;
        String tempStuTableName, crsid, crsn, crsdto, crsinstructor, crscd, crsdesc;
            ///////////////////////////////////////////////////////         
        for(int stuIndex = 0; stuIndex < studentIndicesArray.length; stuIndex++){
            strid = String.valueOf(JTblStudents.getValueAt(studentIndicesArray[stuIndex],0)); //returns the student ID
            strfn = String.valueOf(JTblStudents.getValueAt(studentIndicesArray[stuIndex],1)); //returns the student first name
            strmn = String.valueOf(JTblStudents.getValueAt(studentIndicesArray[stuIndex],2)); //returns the student middle name
            strln = String.valueOf(JTblStudents.getValueAt(studentIndicesArray[stuIndex],3)); //returns the student last name
            strdoa = String.valueOf(JTblStudents.getValueAt(studentIndicesArray[stuIndex],4)); //returns the student date of admittance
            strdesc = String.valueOf(JTblStudents.getValueAt(studentIndicesArray[stuIndex],5)); //returns the student comment
                ///////////////////////////////////////////////////////////////////////////////////////////////////   
            for(int crsIndex = 0; crsIndex < coursesIndicesArray.length; crsIndex++){
                crsid = String.valueOf(JTblCourses.getValueAt(coursesIndicesArray[crsIndex], 0)); //returns the course ID
                crsn = String.valueOf(JTblCourses.getValueAt(studentIndicesArray[crsIndex],1)); //returns the course name
                crsdto = String.valueOf(JTblCourses.getValueAt(studentIndicesArray[crsIndex],2)); //returns the course day and time
                crsinstructor = String.valueOf(JTblCourses.getValueAt(studentIndicesArray[crsIndex],3)); //returns the course instructor
                crscd = String.valueOf(JTblCourses.getValueAt(studentIndicesArray[crsIndex],4)); //returns the course creation date
                crsdesc = String.valueOf(JTblCourses.getValueAt(studentIndicesArray[crsIndex],5)); //returns the course comment
                ///////////////////////////////////////////////////////////////////////////////////////////////////
                    ////create table names/////////////////////////////////////
                tempCrsTableName = crsn + crsid +"Roster";
                tempStuTableName = strfn + strln + strid.substring((strid.length() - 3)) +"Schedule";
                    ///////////////////////////////////////////////////////
                InsertStudentIntoRoster(tempCrsTableName, strid,strfn,strmn, strln, strdoa,strdesc);
                InsertCourseIntoSchedule(tempStuTableName,crsid, crsn, crsdto, crsinstructor, crscd, crsdesc);
                JOptionPane.showMessageDialog(null, "the student \""+JTblStudents.getValueAt(studentIndicesArray[stuIndex],1)+" "+
                        JTblStudents.getValueAt(studentIndicesArray[stuIndex],2)+" "+JTblStudents.getValueAt(studentIndicesArray[stuIndex],3)+
                        "\" has been added to the course \""+JTblCourses.getValueAt(studentIndicesArray[crsIndex],1)+"\" roster \n and the course has been added to the student's schedule");
            }
        }
    }
    
    /**
     * This method does the actual filtering of the Student and Courses table
     * @param i Used to determine whether to search for a Course or s Student
     */
    private void filterStudentsCoursesTable(int i){
        if(i == 1){ //Searching for students only
            ArrayList<Student> tempStudents;
            DefaultTableModel removeTblModel;
            ///////////////////////////////////////////////////////////////////////////////////////////////
            tempStudents = stu.searchListForS(stu.getHeadReference(1), JtxtSearchBoxStudent.getText());
            removeTblModel = (DefaultTableModel)resetTblModel(JTblStudents.getModel());

            if(!tempStudents.isEmpty()){
                for (Student tempStudent : tempStudents) {
                    if(tempStudent != null){
                        removeTblModel.addRow(new Object[]{tempStudent.getStudentID(), tempStudent.getStudentFirstName(),
                            tempStudent.getStudentMiddleName(), tempStudent.getStudentLastName(),
                            tempStudent.getStudentDateOfAdmittance(), tempStudent.getStudentComment()});
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "The student does not exist");
                    }
                }
            }
            else{
                JOptionPane.showMessageDialog(null, "The student does not exist");
            }
        }
        ////////////////////Searching for courses only//////////////////////////////////////////////////////////////////////////////
        if(i == 2){
            Course tempCourse;
            DefaultTableModel removeTblModel;
            tempCourse = (Course) crs.searchListForSC(crs.getHeadReference(2), JtxtSearchBoxCourses.getText());
        
            if(tempCourse != null){
                removeTblModel = (DefaultTableModel)resetTblModel(JTblCourses.getModel());
                removeTblModel.addRow(new Object[]{tempCourse.getCourseID(), tempCourse.getCourseName(), tempCourse.getCourseDayNTime(),
                        tempCourse.getCourseInstructor(),tempCourse.getCourseCreationDate(), tempCourse.getCourseDescription()});
            }
            else{
                JOptionPane.showMessageDialog(null, "The course does not exist");
            }
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmScheduleRosterCreator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmScheduleRosterCreator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmScheduleRosterCreator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmScheduleRosterCreator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmScheduleRosterCreator(false).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JAllCourses;
    private javax.swing.JLabel JAllStudents;
    private javax.swing.JMenu JMenuAbout;
    private javax.swing.JMenuBar JMenuBarSchRos;
    private javax.swing.JMenu JMenuHelp;
    private javax.swing.JPanel JPanelScheduleRosterCreator;
    private javax.swing.JSeparator JSchRosSplitter;
    private javax.swing.JTable JTblCourses;
    private javax.swing.JTable JTblStudents;
    private javax.swing.JTextField JtxtSearchBoxCourses;
    private javax.swing.JTextField JtxtSearchBoxStudent;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
