/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package registrarapp;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * This class contains the methods that are used to add or remove a course or a student to or from
 * the database.
 * @author Kelvin
 * @param <E> Student object or a Course object
 * @see http://www.kelv-b.com
 */
public class GenericEntityCreator<E> {
      
    /**
     * This method adds a student / course object to the database
     * @param cs The Student / Course Object 
     * @return true if the operation was successful, false if otherwise
     */
    public boolean createStudentEntity(E cs){
        int num = -1;//initialized
        PreparedStatement pstmt = null;
        
          if("Student".equals(cs.getClass().getSimpleName())){ 
              try{
                    Connection connector = SqliteDBConnector.ConnectionDb();
                    //////////////////////////////
                    String query = "INSERT INTO tblStudents (studentid, studentfirstN,studentmiddleN,studentlastN,studentdateofadmin,stucomment)"
                            + "VALUES(?,?,?,?,?,?)";
                    pstmt = connector.prepareStatement(query);
                    pstmt.setInt(1, ((Student)cs).getStudentID());
                    pstmt.setString(2, ((Student)cs).getStudentFirstName());
                    pstmt.setString(3, ((Student)cs).getStudentMiddleName());
                    pstmt.setString(4, ((Student)cs).getStudentLastName());
                    pstmt.setString(5, ((Student)cs).getStudentDateOfAdmittance());
                    pstmt.setString(6,((Student)cs).getStudentComment());
                    num = pstmt.executeUpdate();
                    /////////////////////////////////
            }
            catch(SQLException problem){
                JOptionPane.showMessageDialog(null, problem.getMessage());
            }
          }
          
          else if("Course".equals(cs.getClass().getSimpleName())){
                  try{
                    Connection connector = SqliteDBConnector.ConnectionDb();  
                    //////////////////////////////
                    String query = "INSERT INTO tblCourses (CourseID, CourseName,DayTimeOffered, Instructor, CourseCreationDate,CourseDesc)"
                            + "VALUES(?,?,?,?,?,?)";
                    pstmt = connector.prepareStatement(query);
                    pstmt.setInt(1, ((Course)cs).getCourseID());
                    pstmt.setString(2, ((Course)cs).getCourseName());
                    pstmt.setString(3, ((Course)cs).getCourseDayNTime());
                    pstmt.setString(4, ((Course)cs).getCourseInstructor());
                    pstmt.setString(5, ((Course)cs).getCourseCreationDate());
                    pstmt.setString(6,((Course)cs).getCourseDescription());
                    num = pstmt.executeUpdate();
                    /////////////////////////////////
            }
            catch(SQLException problem)
            {
                JOptionPane.showMessageDialog(null, problem.getMessage());
            }
            finally{
                  if(pstmt != null){
                      try {
                          pstmt.close(); //close the preparedstatement
                      } 
                      catch (SQLException ex) {
                          JOptionPane.showMessageDialog(null, ex.getMessage());
                      }
                  }
                  }
          }
///////////////////////////deciding what boolean to return////////////////////////////////////////////////          
          switch(num){
              case 1:
                  return true;
              default:{
                  return false;
              }       
          }
    }
    
    /**
     * This method inserts a student name into a course roster
     * @param tempCrsTableName The name of the course roster
     * @param stuID Student identification number
     * @param stuFN Student first name
     * @param stuMN Student middle name
     * @param stuDOA Student date of admittance
     * @param stuLN Student last name
     * @param stuDesc Student comment
     * @return True if the operation is successful, or false if otherwise
     */
    public static boolean InsertStudentIntoRoster(String tempCrsTableName, String stuID,
            String stuFN, String stuMN, String stuLN, String stuDOA, String stuDesc){
        PreparedStatement pstmt = null;
        try{
            Connection connector = SqliteDBConnector.ConnectionDb();
                    ///////////////////////Validate the table name//////////////////////////////////
            tempCrsTableName = tableNameValidator(tempCrsTableName); //courseN_courseID
                    //////////////////////////////
            String query = "INSERT INTO "+ tempCrsTableName +" (studentid, studentfirstN,studentmiddleN,studentlastN,studentdateofadmin,stucomment)"
                         + "VALUES(?,?,?,?,?,?)";
                 pstmt = connector.prepareStatement(query);
                 ////////////////////////////////////////
                 pstmt.setString(1, stuID);
                 pstmt.setString(2, stuFN);
                 pstmt.setString(3, stuMN);
                 pstmt.setString(4, stuLN);
                 pstmt.setString(5, stuDOA);
                 pstmt.setString(6, stuDesc);
                 pstmt.executeUpdate();
                    /////////////////////////////////
                 pstmt.close();
                 connector.close();
                 return true;
             }
             catch(SQLException problem){
                 JOptionPane.showMessageDialog(null, problem.getMessage());
                 return false;
             }
    }
    
    /**
     * This method inserts a course into a students schedule
     * @param tempStuTableName The name of the student schedule
     * @param crsid the course identification number
     * @param crsn the course name
     * @param crsdto the day and time course is offered
     * @param crsinstructor the course instructor / teacher
     * @param crsccd the course creation date 
     * @param crscomment the course description / comment
     * @return True if the operation is successful, and false if not
     */
    public static boolean InsertCourseIntoSchedule(String tempStuTableName, String crsid, String crsn, String crsdto,
            String crsinstructor, String crsccd, String crscomment){
        PreparedStatement pstmt = null;
        try{
            Connection connector = SqliteDBConnector.ConnectionDb();
                    ///////////////////////Validate the table name//////////////////////////////////
            tempStuTableName = tableNameValidator(tempStuTableName); //courseN_courseID
                    //////////////////////////////
            String query = "INSERT INTO "+ tempStuTableName +" (CourseID, CourseName,DayTimeOffered,Instructor,CourseCreationDate,CourseDesc)"
                         + "VALUES(?,?,?,?,?,?)";
                 pstmt = connector.prepareStatement(query);
                 ////////////////////////////////////////
                 pstmt.setString(1, crsid);
                 pstmt.setString(2, crsn);
                 pstmt.setString(3, crsdto);
                 pstmt.setString(4, crsinstructor);
                 pstmt.setString(5, crsccd);
                 pstmt.setString(6, crscomment);
                 pstmt.executeUpdate();
                    /////////////////////////////////
                 pstmt.close();
                 connector.close();
                 return true;
             }
             catch(SQLException problem){
                 JOptionPane.showMessageDialog(null, problem.getMessage());
                 return false;
             }
    }
    
    /**
     * This method creates a student schedule when the student is added to the institution, or 
     * it creates a course roster when the course is added to the institution.
     * @param cs2 A Course or Student
     * @return true if the operation is successful or false if otherwise
     */
    public boolean RosterScheduleCreator (E cs2){
        String tempTableName = "";
        
        if("Student".equals(cs2.getClass().getSimpleName())){
            try
            {
       //////////////////Creating student schedule table name/////////////////////////////
                String strStuScheduleName = ((Student)cs2).getStudentFirstName() + ((Student)cs2).getStudentLastName()+
                        String.valueOf(((Student)cs2).getStudentID()).substring(String.valueOf(((Student)cs2).getStudentID()).length() - 3)+"Schedule";
        ////////validating table name////////////////////////////////////////////////
                strStuScheduleName = tableNameValidator(strStuScheduleName);
                /////////////////////////
                Connection connector = SqliteDBConnector.ConnectionDb();
                String query2 = "CREATE TABLE "+strStuScheduleName+ " (CourseID INTEGER PRIMARY KEY NOT NULL, "
                        + "CourseName VARCHAR NOT NULL,DayTimeOffered VARCHAR NOT NULL, "
                        + "Instructor VARCHAR NOT NULL, CourseCreationDate VARCHAR NOT NULL, "
                        + "CourseDesc VARCHAR NOT NULL)";
                Statement stmt = connector.createStatement();
                stmt.execute(query2);
                stmt.close();//close the statement
                connector.close();//close the connection
                return true;
            }
            catch(HeadlessException | SQLException problem2)
            {
                JOptionPane.showMessageDialog(null, problem2.getMessage());
                return false;
            }
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////        
        else if ("Course".equals(cs2.getClass().getSimpleName())){
            try
            {//////////////////Creating Course roster table name/////////////////////////////
                String strCrsRosterName = ((Course)cs2).getCourseName() + String.valueOf(((Course)cs2).getCourseID())
                        +"Roster";
        ///////////////////////////////////////////////////////Valditating table name/
                strCrsRosterName = tableNameValidator(strCrsRosterName);
                //////////////////////////////////////////////////
                Connection connector2 = SqliteDBConnector.ConnectionDb();
                String query2 = "CREATE TABLE "+ strCrsRosterName + "(studentid INTEGER PRIMARY KEY NOT NULL, studentfirstN VARCHAR NOT NULL, "
                        + "studentmiddleN VARCHAR, studentlastN VARCHAR NOT NULL, "
                        + "studentdateofadmin VARCHAR NOT NULL, stucomment VARCHAR NOT NULL)";
                Statement stmt2 = connector2.createStatement();
                stmt2.execute(query2);
                stmt2.close(); //close the statement
                connector2.close();//close the connection
                return true;
            }
            catch(HeadlessException | SQLException problem2)
            {
                JOptionPane.showMessageDialog(null, problem2.getMessage());
                return false;
            }
        }
        return false;
    }
    
    /**
     * This method deletes a student schedule, or a course roster from the database
     * @param cs3 The Course or Student
     * @return true, if the operation is successful, or false if otherwise
     */
    public boolean RosterScheduleDeleter(E cs3){
        String tempTableName="";
///////////delete the student schedule first///////////////////////////////
        if("Student".equals(cs3.getClass().getSimpleName())){
            try{//////////////////Creating student schedule table name/////////////////////////////
                String strStuScheduleName = ((Student)cs3).getStudentFirstName() + ((Student)cs3).getStudentLastName()+
                        String.valueOf(((Student)cs3).getStudentID()).substring(String.valueOf(((Student)cs3).getStudentID()).length() - 3)+"Schedule";
                ////////validating table name////////////////////////////////////////////////
                 tempTableName = tableNameValidator(strStuScheduleName);
                /////////////////////////
                Connection connector = SqliteDBConnector.ConnectionDb();
                String query2 = "DROP TABLE "+tempTableName;
                Statement stmt = connector.createStatement();
                stmt.execute(query2);
                stmt.close();//close the statement
                connector.close();//close the connection
                return true;
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage());
                return false;
            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////        
        else if ("Course".equals(cs3.getClass().getSimpleName())){
            try
            {//////////////////Creating Course roster table name/////////////////////////////
                String strCrsRosterName = ((Course)cs3).getCourseName() + String.valueOf(((Course)cs3).getCourseID())
                        +"Roster";
        ///////////////////////////////////////////////////////Valditating table name/
                tempTableName = strCrsRosterName.replace(" ", "");
                tempTableName = tempTableName.replace("'", "");
                tempTableName = tempTableName.replace(",", "");
                tempTableName = tempTableName.replace("?", "");//remove ?
                tempTableName = tempTableName.replace(">", "");
                tempTableName = tempTableName.replace("<", "");
                tempTableName = tempTableName.replace("[", "");
                tempTableName = tempTableName.replace("]", "");
                tempTableName = tempTableName.replace("(", "");
                tempTableName = tempTableName.replace(")", "");
                tempTableName = tempTableName.replace("/", "");
                tempTableName = tempTableName.replace("\\", "");
                tempTableName = tempTableName.replace("-", "");
                tempTableName = tempTableName.replace("_", "");
                tempTableName = tempTableName.replace("%", "");
                tempTableName = tempTableName.replace("^", "");
                tempTableName = tempTableName.replace("&", "");
                tempTableName = tempTableName.replace("*", "");
                tempTableName = tempTableName.replace("#", "");
                tempTableName = tempTableName.replace("@", "");
                tempTableName = tempTableName.replace("!", "");
                tempTableName = tempTableName.replace("~", "");
                tempTableName = tempTableName.replace("`", "");
                tempTableName = tempTableName.replace("\"", "");
                tempTableName = tempTableName.replace("+", "");
                tempTableName = tempTableName.replace("=", "");
                tempTableName = tempTableName.replace("|", "");
                //////////////////////////////////////////////////
                Connection connector2 = SqliteDBConnector.ConnectionDb();
                String query2 = "DROP TABLE "+ tempTableName;
                Statement stmt2 = connector2.createStatement();
                stmt2.execute(query2);
                stmt2.close(); //close the statement
                connector2.close();//close the connection
                return true;
            }
            catch(SQLException problem2){
                JOptionPane.showMessageDialog(null, problem2.getMessage());
                return false;
            }
        }
        return false;
    }
    
    /**
     * This method removes a student or a course from the institution database
     * @param cs4 The Student or Course
     * @return true if the operation is successful or false if not
     */
    public boolean RemoveCourseStudentFromTbl(E cs4){
        if("Student".equals(cs4.getClass().getSimpleName())){
            try{
                /////////////////////////
                Connection connector2 = SqliteDBConnector.ConnectionDb();
                String query2 = "DELETE FROM tblStudents WHERE studentid = ?";
                PreparedStatement pstmt2 = connector2.prepareStatement(query2);
                pstmt2.setString(1, String.valueOf(((Student)cs4).getStudentID()));
                pstmt2.executeUpdate();
                pstmt2.close(); //close the statement
                connector2.close();//close the connection
                return true;
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage());
                return false;
            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////        
        else if ("Course".equals(cs4.getClass().getSimpleName())){
            try
            {//////////////////////////////////////////////////
                Connection connector2 = SqliteDBConnector.ConnectionDb();
                String query2 = "DELETE FROM tblCourses WHERE CourseID = ?";
                PreparedStatement pstmt2 = connector2.prepareStatement(query2);
                pstmt2.setString(1, String.valueOf(((Course)cs4).getCourseID()));
                pstmt2.executeUpdate();
                pstmt2.close(); //close the statement
                connector2.close();//close the connection
                return true;
            }
            catch(SQLException problem2){
                JOptionPane.showMessageDialog(null, problem2.getMessage());
                return false;
            }
        }
        return false;
    }
    
    /**
     * This method removes certain characters from the table name
     * @param tempTableName the name of the database table
     * @return the table name with unwanted characters removed
     */
    public static String tableNameValidator(String tempTableName){
        tempTableName = tempTableName.replace(" ", "");
        tempTableName = tempTableName.replace("'", "");
        tempTableName = tempTableName.replace(",", "");
        tempTableName = tempTableName.replace("?", "");//remove ?
        tempTableName = tempTableName.replace(">", "");
        tempTableName = tempTableName.replace("<", "");
        tempTableName = tempTableName.replace("[", "");
        tempTableName = tempTableName.replace("]", "");
        tempTableName = tempTableName.replace("(", "");
        tempTableName = tempTableName.replace(")", "");
        tempTableName = tempTableName.replace("/", "");
        tempTableName = tempTableName.replace("\\", "");
        tempTableName = tempTableName.replace("-", "");
        tempTableName = tempTableName.replace("_", "");
        tempTableName = tempTableName.replace("%", "");
        tempTableName = tempTableName.replace("^", "");
        tempTableName = tempTableName.replace("&", "");
        tempTableName = tempTableName.replace("*", "");
        tempTableName = tempTableName.replace("#", "");
        tempTableName = tempTableName.replace("@", "");
        tempTableName = tempTableName.replace("!", "");
        tempTableName = tempTableName.replace("~", "");
        tempTableName = tempTableName.replace("`", "");
        tempTableName = tempTableName.replace("\"", "");
        tempTableName = tempTableName.replace("+", "");
        tempTableName = tempTableName.replace("=", "");
        tempTableName = tempTableName.replace("|", "");
        return tempTableName;
    }

    /**
     * This method updates a student information in the institution, or updates a course information in the institution.
     * Additionally, it updates the name on a students schedule, or updates the name on a course roster
     * @param sc The Student or Course
     * @param tblOldName The old student schedule, or course roster name
     * @return true, if the operation is successful.
     */
    protected boolean StudentCourseUpdater(E sc, String tblOldName){
        String tableNewName="";
        /////////
                tblOldName = tableNameValidator(tblOldName); //validating old table name
        ///////////        
        if("Student".equals(sc.getClass().getSimpleName())){
            try{
                Student tempStudent;
                tempStudent = (Student)sc;
                Connection connector2 = SqliteDBConnector.ConnectionDb();
                String queryStr = "UPDATE tblStudents SET studentfirstN = ?, studentmiddleN = ?, studentlastN = ?, studentdateofadmin = ?, "
                        + " stucomment = ? WHERE studentid = ?";
                PreparedStatement pstmt = connector2.prepareStatement(queryStr);
                pstmt.setString(1, tempStudent.getStudentFirstName());
                pstmt.setString(2, tempStudent.getStudentMiddleName());
                pstmt.setString(3, tempStudent.getStudentLastName());
                pstmt.setString(4, tempStudent.getStudentDateOfAdmittance());
                pstmt.setString(5, tempStudent.getStudentComment());
                pstmt.setString(6, String.valueOf(tempStudent.getStudentID()));
                pstmt.executeUpdate();
                pstmt.close();
                connector2.close();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
            //###############################################################################################
            try{
                Student tempStudent = (Student)sc;
                ///////////////////////////Creating the table's new name/////////
                tableNewName = tempStudent.getStudentFirstName() + tempStudent.getStudentLastName() + 
                        String.valueOf(tempStudent.getStudentID()).substring(String.valueOf(tempStudent.getStudentID()).length()-3)+"Schedule";
                tableNewName = tableNameValidator(tableNewName);
                /////////////////////////////////////
                Connection connector2 = SqliteDBConnector.ConnectionDb();
                String queryStr = "ALTER TABLE "+tblOldName+" RENAME TO " + tableNewName + ";";
                Statement stmt = connector2.createStatement();
                stmt.executeUpdate(queryStr);
                stmt.close();
                connector2.close();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        else if("Course".equals(sc.getClass().getSimpleName())){
            try {
                Course tempCourse;
                tempCourse = (Course)sc;
                Connection connector2 = SqliteDBConnector.ConnectionDb();
                String queryStr = "UPDATE tblCourses SET CourseName = ?, DayTimeOffered = ?, Instructor = ?, "
                        + "CourseCreationDate = ?, CourseDesc = ? WHERE CourseID = ?";
                PreparedStatement pstmt = connector2.prepareStatement(queryStr);
                pstmt.setString(1, tempCourse.getCourseName());
                pstmt.setString(2, tempCourse.getCourseDayNTime());
                pstmt.setString(3, tempCourse.getCourseInstructor());
                pstmt.setString(4, tempCourse.getCourseCreationDate());
                pstmt.setString(5, tempCourse.getCourseDescription());
                pstmt.setString(6, String.valueOf(tempCourse.getCourseID()));
                pstmt.executeUpdate();
                pstmt.close();
                connector2.close();
            }
            catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
            //###############################################################################################
            try{
                Course tempCourse = (Course)sc;
                /////////////////////////Creating the table's new name/////////////////////////////////////////
                tableNewName = tempCourse.getCourseName()+ String.valueOf(tempCourse.getCourseID())+"Roster";
                tableNewName = tableNameValidator(tableNewName);
                
                ////////////////////////////////////////////////////////////////////
                Connection connector2 = SqliteDBConnector.ConnectionDb();
                String queryStr = "ALTER TABLE "+tblOldName+" RENAME TO " + tableNewName + ";";
                Statement stmt = connector2.createStatement();
                stmt.executeUpdate(queryStr);
                stmt.close();
                connector2.close();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
        return true;
    }
}
