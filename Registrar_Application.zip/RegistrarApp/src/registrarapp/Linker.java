/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package registrarapp;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import static registrarapp.ControlsInterface.crs;

/**
 *
 * @author Kelvin
 * @param <E> Student or Course
 */
public class Linker <E> {
    private static SCNode courseHead = null, studentHead = null;//head pointer
    
    private static SCNode courseTail = null, studentTail = null;//tail pointer
    private static SCNode studentCursorOne = null, courseCursorOne = null, studentOne = null;//
    private static SCNode studentCursorTwo = null, courseCursorTwo = null, courseOne = null;//
    public static int studentNodeCounter = 0, courseNodeCounter = 0;
    
    /**
     * This method creates the dummy nodes at the start of the application
     * @param i
     * @return true, when the operation is successful.
     */
    public boolean createDummyNodes(int i)
    {
        if(1 == i){
            studentHead = new SCNode(null);//create a dummy head node
            studentTail = new SCNode(studentHead); //create a dummy tail node
            return true;
        }
        else if(i == 2){
            courseHead = new SCNode(null);
            courseTail = new SCNode(courseHead);
            return true;
        }
        
        else{
            return false;
        }
    }
    
    /**
     * This method inserts a node at the end of the list
     * @param element The element stored in the new node
     * @param lisCounter The length of the linked-list
     * @return true, when the operation is successful false if otherwise
     */
    protected boolean addNodeAfter(E element, int lisCounter)
    {
        if("Student".equals(element.getClass().getSimpleName()) && lisCounter <= 0){//there aren't any nodes in the list
            studentHead.setNext(new SCNode(element, studentHead, studentTail));
            Linker.studentNodeCounter += 1;
            return true;
        }
        
        else if("Course".equals(element.getClass().getSimpleName()) && lisCounter <= 0){//there aren't any nodes in the list
            courseHead.setNext(new SCNode(element, courseHead, courseTail)); 
            Linker.courseNodeCounter += 1;
            return true;
        }
//////////////////////////////////////////////////////////////////////
        
        else if("Student".equals(element.getClass().getSimpleName()) && lisCounter > 0){//there is at least one node in the list
            studentOne = studentTail.getPrev();//set the two pointer
            studentTail.setPrev(new SCNode(element, studentOne, studentTail));//insert the node in between the two pointers
            Linker.studentNodeCounter += 1;
            return true;
        }
        
        else if("Course".equals(element.getClass().getSimpleName()) && lisCounter > 0){
            courseOne = courseTail.getPrev(); //set the two pointer
            courseTail.setPrev(new SCNode(element, courseOne, courseTail));
            Linker.courseNodeCounter += 1;
            return true;
        }
        return false;
    }
    
    /**
     * This method removes a node from the respective list, that is Student list or
     * Course list
     * @param data The Student or Course entity
     * @param i Used to determine if its a Student or a Course
     * @param listCounter The length of the linked list 
     * @return true if the operation is successful, false if otherwise
     */
    protected boolean removeNode(E data, int i, int listCounter)
    {
        if(i == 1 && "Student".equals(data.getClass().getSimpleName())){
            if(studentHead == null && studentTail == null){
                JOptionPane.showMessageDialog(null, "The list is empty");
                return false;
            }
            
            else{
                //int num = 0;    //   this will account for TDN
                for(SCNode x = studentHead.getNext(); x.getNext() != null; x = x.getNext())
                {
                    if(((Student)x.getData()).getStudentID() == ((Student)data).getStudentID()){
                        studentCursorOne = x.getPrev();//set the before pointer
                        studentCursorTwo = x.getNext();// set the after pointer
                        //////////////////////////
                        studentCursorOne.setNext(studentCursorTwo);
                        studentCursorTwo.setPrev(studentCursorOne);
                        Linker.studentNodeCounter -= 1;                
                        break;
                    }
                }
                return true;
            }
        }
        /////////////////////////////////////////////////////////////////////
        else if("Course".equals(data.getClass().getSimpleName()) && i == 2){
            if(courseHead == null && courseTail == null){
                JOptionPane.showMessageDialog(null, "The list is empty");
                return false;
            }

            else{
                for(SCNode x = courseHead.getNext(); x.getNext() != null; x = x.getNext())
                {
                    if(((Course)x.getData()).getCourseID() == ((Course)data).getCourseID()){
                        courseCursorOne = x.getPrev();//set the before pointer
                        courseCursorTwo = x.getNext();// set the after pointer
                        //////////////////////////
                        courseCursorOne.setNext(courseCursorTwo);
                        courseCursorTwo.setPrev(courseCursorOne);
                        Linker.courseNodeCounter -= 1;            
                        return true;
                    }
                }
                return true;
            }
        }
        return false;
    }
    
    
    /**
     * This method removes a node from the respective list, that is Student list or
     * Course list
     * @param data The Student or Course entity
     * @param i Used to determine if its a Student or a Course
     * @param index The index of the node being removed
     * @param listCounter The length of the linked list 
     * @return true if the operation is successful, false if otherwise
     */
    protected boolean removeNode(E data, int index, int i, int listCounter)
    {
        if(i == 1 && "Student".equals(data.getClass().getSimpleName())){
            if(studentHead == null && studentTail == null){
                JOptionPane.showMessageDialog(null, "The list is empty");
                return false;
            }
            else if(index >= listCounter){
                JOptionPane.showMessageDialog(null, "Index is out of range");
                return false;
            }

            else{
                int num = 0;    //   this will account for TDN
                for(SCNode x = studentHead.getNext(); x.getNext() != null; x = x.getNext())
                {
                    if(num == index && ((Student)x.getData()).getStudentID() == ((Student)data).getStudentID()){
                        studentCursorOne = x.getPrev();//set the before pointer
                        studentCursorTwo = x.getNext();// set the after pointer
                        //////////////////////////
                        studentCursorOne.setNext(studentCursorTwo);
                        studentCursorTwo.setPrev(studentCursorOne);
                        Linker.studentNodeCounter -= 1;                
                        break;
                    }
                    num++;
                }
                return true;
            }
        }/////////////////////////////////////////////////////////////////////
        else if("Course".equals(data.getClass().getSimpleName()) && i == 2){
            if(courseHead == null && courseTail == null){
                JOptionPane.showMessageDialog(null, "The list is empty");
                return false;
            }
            else if(index >= listCounter){
                JOptionPane.showMessageDialog(null, "Index is out of range");
                return false;
            }

            else{
                int num = 0;    //   this will account for TDN
                for(SCNode x = courseHead.getNext(); x.getNext() != null; x = x.getNext())
                {
                    if(((Course)x.getData()).getCourseID() == ((Course)data).getCourseID() && num == index){
                        courseCursorOne = x.getPrev();//set the before pointer
                        courseCursorTwo = x.getNext();// set the after pointer
                        //////////////////////////
                        courseCursorOne.setNext(courseCursorTwo);
                        courseCursorTwo.setPrev(courseCursorOne);
                        Linker.courseNodeCounter -= 1;            
                        break;
                    }
                    num++;
                }
                return true;
            }
        }
        return false;
    }
    
    /**
     * This method searches the respective linked-list for the given value.
     * @param tempHead A reference to the Head Dummy Node
     * @param searchValue The value being searched for
     * @return A Course or a Student object
     */
    protected E searchListForSC(SCNode tempHead, String searchValue){ 
        if("Student".equals(tempHead.getNext().getData().getClass().getSimpleName())){
            for(SCNode y1 = tempHead.getNext(); y1.getNext() != null; y1 = y1.getNext()){
                
                Student tempStudent = (Student)y1.getData();
                if(Integer.toString(tempStudent.getStudentID()).equals(searchValue) || tempStudent.getStudentFirstName().compareToIgnoreCase(searchValue) == 0 || tempStudent.getStudentLastName().compareToIgnoreCase(searchValue) == 0){
                    return (E)tempStudent;
                }
            }
        }
        else if("Course".equals(tempHead.getNext().getData().getClass().getSimpleName())){
            
            for(SCNode y1 = tempHead.getNext(); y1.getNext() != null; y1 = y1.getNext()){    
                Course tempCourse = (Course)y1.getData();
                if(tempCourse.getCourseName().compareToIgnoreCase(searchValue) == 0 || Integer.toString(tempCourse.getCourseID()).equals(searchValue)){
                    return (E)tempCourse;
                }
            }
        }
        return null;//account for null by issuing a message
    }
    
    /**
     * This method returns a list of students who have the specified credential
     * @param tempHead A reference to the head of the student linked-list
     * @param searchValue The value being used as the basis for the search
     * @return A list of students with the specified credential
     */
    protected ArrayList<Student> searchListForS(SCNode tempHead, String searchValue){
        ArrayList<Student> ar;
        ar = new ArrayList<>();
            ///////////////////////////////////////////////////////////////////////////
        if("Student".equals(tempHead.getNext().getData().getClass().getSimpleName())){
            for(SCNode y1 = tempHead.getNext(); y1.getNext() != null; y1 = y1.getNext()){
            //////////////////////////////////////////////////////////////////////////////////

               Student tempStudent = (Student)y1.getData();
                    if(Integer.toString(tempStudent.getStudentID()).equals(searchValue) || tempStudent.getStudentFirstName().compareToIgnoreCase(searchValue) == 0 || tempStudent.getStudentLastName().compareToIgnoreCase(searchValue) == 0){
                        ar.add(tempStudent);
                    }
                }
        }
        return ar;
    }
    
     /**
     * This method returns a list of courses who have the specified credential
     * @param tempHead A reference to the head of the course linked-list
     * @param tblName A reference to the Table
     * @param tbl an array of indices of the selected rows
     * @return A list of Courses with the specified credential
     */
    protected ArrayList<Course> searchListForC(SCNode tempHead, JTable tblName, int [] tbl){
        ArrayList<Course> ar;
        ar = new ArrayList<>();
            ///////////////////////////////////////////////////////////////////////////
        if("Course".equals(tempHead.getNext().getData().getClass().getSimpleName())){
     
            for(int x = 0; x < tbl.length; x++){
                for(SCNode y1 = tempHead.getNext(); y1.getNext() != null; y1 = y1.getNext()){
                    Course tempCourse = (Course)y1.getData();//                        row X column
                    if(String.valueOf(tempCourse.getCourseID()).equals((String)tblName.getValueAt(tbl[x], 0))){
                        ar.add(tempCourse);
                    }
                }
            }  
        }
        return ar;
    }
    
     /**
     * This method returns a list of students who have the specified credential
     * @param tempHead A reference to the head of the course linked-list
     * @param tblName A reference to the Table
     * @param tbl an array of indices of the selected rows
     * @return A list of Student with the specified credential
     */
        protected ArrayList<Student> searchListForS(SCNode tempHead, JTable tblName, int [] tbl){
        ArrayList<Student> ar;
        ar = new ArrayList<>();
            ///////////////////////////////////////////////////////////////////////////
        if("Student".equals(tempHead.getNext().getData().getClass().getSimpleName())){
     
            for(int x = 0; x < tbl.length; x++){
                for(SCNode y1 = tempHead.getNext(); y1.getNext() != null; y1 = y1.getNext()){
                    Student tempStudent = (Student)y1.getData();//                        row X column
                    if(String.valueOf(tempStudent.getStudentID()).equals((String)tblName.getValueAt(tbl[x], 0))){
                        ar.add(tempStudent);
                    }
                }
            }  
        }
        return ar;
    }
    
    /**
     * This method returns the head reference to the linked-list
     * @param i Used to determine whether its a Student or a Course
     * @return A reference to the Head Dummy Node
     */
    protected SCNode getHeadReference(int i){
        if(i == 1)
            return studentHead;
        else if(i == 2)
            return courseHead;
        else{return null;}
    }
    
    /**
     * This method returns the tail reference to the linked-list
     * @param i Used to determine whether its a Student or a Course
     * @return A reference to the Tail Dummy Node
     */
    protected  SCNode getTailReference(int i){
        if(i == 1)
            return studentTail;
        else if(i == 2)
            return courseTail;
        else{
            return null;
        }
    }
}
