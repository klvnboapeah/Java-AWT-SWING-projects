/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package registrarapp;

import javax.swing.JOptionPane;

/**
 * 
 * @author Kelvin .B
 */
public class SCNode<E>{
    public SCNode next;//points to the next node 
    public SCNode prev;//points to the previous node
    private E data;//can hold any data type, namely - Course anD Student object
    
    /**
     * This method only creates a head dummy node and a tail dummy node
     * @param value null or head
     */
    public SCNode(SCNode value)
    {
        if(value == null)
        {
            data = null;
            prev = null;
            next = null;
        }
        else{
            data = null;
            prev = value;
            next = null;
            ////////////
            value.next = this; //point HDN's next to TDN
        }
    }
    
    /**
     * This method creates a node in the respective list, that is Student list or
     * Course list
     * @param ele The Student or course object
     * @param valueHead The head pointer
     * @param valueTail  The tail pointer
     */
    public SCNode(E ele, SCNode valueHead, SCNode valueTail)
    {
        data = ele;
        next = valueTail;
        prev = valueHead;
        valueHead.next = this;
        valueTail.prev = this;
    }
    
    /**
     * This method returns the data stored in the node
     * @return a Student object or a Course object
     */
    public E getData(){
        return data;
    }
    
    /**
     * This method returns the next node after this node
     * @return A reference to the next node
     */
    public SCNode getNext(){return next;}
    
    /**
     * This method returns the previous node before this node
     * @return A reference to the previous node
     */
    public SCNode getPrev(){return prev;}
    ///////////////////////////////////////////////////////////////////////////
    /**
     * This method sets the data of this node to either a Student or Course node
     * @param val the data to be stored in the node
     * @return true, when the operation is successful
     */
    public boolean setData(E val){
        this.data = val;
        return true;}
    
    /**
     * This method sets the next reference of this node to point to a node
     * @param val The reference to a different node
     * @return true, when the operation is successful
     */
    public boolean setNext(SCNode val){
        this.next = val;
        return true;
    }
    
    /**
     * This method sets the previous reference of this node to point to a node
     * @param val2 The reference to a different node
     * @return true, when the operation is successful
     */
    public boolean setPrev(SCNode val2){
        this.prev = val2;
        return true;
    }
}
