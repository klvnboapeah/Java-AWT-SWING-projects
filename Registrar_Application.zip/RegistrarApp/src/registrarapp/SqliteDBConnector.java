/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package registrarapp;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


/**
 * This class returns a connection to the sqlite database
 * @author Kelvin
 */
public class SqliteDBConnector {
    //member variables//

    /**
     * This method returns a connection to the sqlite database
     * @return An SQLite Database Connection
     */
    public static Connection ConnectionDb(){   
        try{
            Connection conn;
            // load the sqlite-JDBC driver using the current class loader
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:"+System.getProperty("user.dir")+"\\src\\rappDB.sqlite");
            return conn;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
}
