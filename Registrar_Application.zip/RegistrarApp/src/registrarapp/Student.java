/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package registrarapp;

import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Kelvin
 * @description This is the class for the student object.
 * @see http://www.kelv-b.com
 */
public class Student {
    private int studentID;
    private String studentFirstName;
    private String studentMiddleName;
    private String studentLastName;
    private String studentDateOfAdmittance;
    private String studentComment;
    
    /**
     * This is the no-argument constructor for the student object
     * 
     **/
    public Student() {this.studentDateOfAdmittance = String.valueOf(new Timestamp(new Date().getTime()));}

    /**
     * This is the constructor for the student object
     * @param studentID The student identification number
     * @param studentFirstName The student's first name
     * @param studentMiddleName The student's middle name
     * @param studentLastName The student's last name
     * @param studentComment The comment / notes about the student
     */
    public Student(int studentID, String studentFirstName, String studentMiddleName, String studentLastName, String studentComment)
    {
        this.studentID = studentID;
        this.studentFirstName = studentFirstName;
        this.studentMiddleName = studentMiddleName;
        this.studentLastName = studentLastName;
         this.studentDateOfAdmittance = String.valueOf(new Timestamp(new Date().getTime()));
        this.studentComment = studentComment;
    }
    
    /**
     * This is the constructor for the student object
     * @param studentID The student identification number
     * @param studentFirstName The student's first name
     * @param studentMiddleName The student's middle name
     * @param studentLastName The student's last name
     * @param studentDateOfAdmittance The student's date of admittance to the institution
     * @param studentComment  Comment/Description about the student
     */
     public Student(int studentID, String studentFirstName, String studentMiddleName, String studentLastName, String studentDateOfAdmittance, String studentComment)
    {
        this.studentID = studentID;
        this.studentFirstName = studentFirstName;
        this.studentMiddleName = studentMiddleName;
        this.studentLastName = studentLastName;
         this.studentDateOfAdmittance = studentDateOfAdmittance;
        this.studentComment = studentComment;
    }
    
    //Mutators///////////////////////////////////////////////////////////////
    /**
     * Sets the students Identification number
     * @param id The new identification number given
     */
    public void setStudentID(int id){studentID = id;}
    
    /**
     * Sets the student's First Name
     * @param firstN The first name given
     */
    public void setFirstName(String firstN){studentFirstName = firstN;}
    
    /**
     * Sets the student's middle name
     * @param middleName The middle name given
     */
    public void setMiddleName(String middleName){studentMiddleName = middleName;}
    
    /**
     * Sets the student's last name 
     * @param lastName The last name given
     */
    public void setLastName(String lastName){studentLastName = lastName;}
    
    /**
     * Sets the date the student was admitted to the institution
     * @param dateOfAdmittance The date the student was admittance to the educational institution
     */
    public void setDateOfAdmittance(String dateOfAdmittance){studentDateOfAdmittance = dateOfAdmittance;}
    
    /**
     * Sets the comment / note about the student
     * @param com The comment / note about the student
     */
    public void setStudentComment(String com){studentComment = com;}
    
    //Accessors/////////////////////////////////////////////////////////////////
  
    /**
     * Gets the student's identification number
     * @return The student identification number (integer)
     */
    public int getStudentID(){return this.studentID;}
    
    /**
     * Gets the student's first name
     * @return The student's first name (String)
     */
    public String getStudentFirstName(){return this.studentFirstName;}
    
    /**
     * Gets the student's middle name
     * @return The student's middle name (String)
     */
    public String getStudentMiddleName(){return this.studentMiddleName;}
    
    /**
     * Gets the student's last name
     * @return The student's last name (String)
     */
    public String getStudentLastName(){return this.studentLastName;}
    
    /**
     * Gets the student's date of admittance
     * @return The date the student was admitted to the institution (String)
     */
    public String getStudentDateOfAdmittance(){return this.studentDateOfAdmittance;}
    
    /**
     * Gets the comment / note about the student
     * @return The comment / note about the student
     */
    public String getStudentComment(){return this.studentComment;}
    ///////////////////////////////////////////////////////////////////////////
    
    /**
     * This method parses the student's name, which is comprised on "first name", "last name", and "middle name"
     * @param str The student's name
     * @param stu The student object 
     * @return A boolean
     */
    public static boolean parseStudentName(String str, Student stu)
    {
        int letterIndex = 0, x = 0, spaceCounter = 0;
        String[] names;
        
        //////////Remove leading and trailing spaces//////////
        str = str.trim();
        ///////////////////////
        
        for(int y = 0; y < str.length(); y++)
        {//only a 3 names are allowed
            if(str.charAt(y) == ' '){spaceCounter++;}//tally up the number of spaces in the student's name
        }
        
        if(spaceCounter == 1)
        {
            names = new String[2]; //first name and last name
            names[0] = "";
            names[1] = "";
            while(letterIndex < str.length())
            {
                if(str.charAt(letterIndex) != ' ')
                {
                   names[x] += str.charAt(letterIndex);
                }

                else if(str.charAt(letterIndex) == ' '){x++;} //1, 2

                letterIndex++;

            }
            stu.studentFirstName = names[0];
            stu.studentLastName = names[1];
        }
        
        else
        {
            names = new String[3]; //first name, middle name, and last name
            names[0] = "";
            names[1] = "";
            names[2] = "";
            while(letterIndex < str.length())
            {
                if(str.charAt(letterIndex) != ' ')
                {
                   names[x] += str.charAt(letterIndex);
                }

                else if(str.charAt(letterIndex) == ' '){x++;} //1, 2

                letterIndex++;
            }
            stu.studentFirstName = names[0];
            stu.studentMiddleName = names[1];
            stu.studentLastName = names[2];
        }
        return true;
    }
}
